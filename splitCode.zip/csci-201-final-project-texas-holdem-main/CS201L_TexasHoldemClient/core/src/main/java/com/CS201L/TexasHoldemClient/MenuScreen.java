package com.CS201L.TexasHoldemClient;

import com.CS201L.TestingSuite.GameTestScreen;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.Viewport;

/**
 * Acts as the entry point for the game allowing the user to select how to proceed.
 * 
 * <p>TODO: Create the actual gameplay buttons
 * <p>TODO: See if there are any options we might want for the GUI or whatnot
 * 
 * @author Nikolas Nguyen
 */
public class MenuScreen extends BaseScreen {
	public static LoginScreen loginScreen;
	
	public MenuScreen(Viewport viewport) { super(viewport); }

	@Override
	public void initialize() {
		// Load the background image for the menu
		new GameElement(0, 0, mainStage).loadTexture("Menu.jpg");
		
		// Initialize a button that leads to a screen for the user's login info
		ButtonElement loginButton = new ButtonElement(1024, 512, uiStage);
		loginButton.setText("Login");
		loginButton.setActionPressed(() -> { 
			if(loginScreen == null)
				BaseGame.setActiveScreen(loginScreen = new LoginScreen(viewport, this));
			else BaseGame.setActiveScreen(loginScreen);
		});
		
		// Initialize a button that runs the display test
		// TODO: Replace with other gameplay options like guest blackjack or whatever
		ButtonElement playButton = new ButtonElement(1024, 412, uiStage);
		playButton.setText("Play Offline");
		playButton.setActionPressed(() -> { 
			BaseGame.setActiveScreen(new BlackjackScreen(viewport, this));
		});
		
		ButtonElement debugTestButton = new ButtonElement(1024, 412, uiStage);
		debugTestButton.setText("Debug");
		debugTestButton.setActionPressed(() -> { 
			BaseGame.setActiveScreen(new GameTestScreen(viewport, this));
		});
		debugTestButton.setVisible(false);
		
		Table buttonDisplay = new Table();
		buttonDisplay.setFillParent(true);
		uiStage.addActor(buttonDisplay);
		buttonDisplay.padBottom(100).bottom();
		
		buttonDisplay.add(loginButton).prefHeight(128).center();
		buttonDisplay.row().padTop(25);
		buttonDisplay.add(playButton).prefHeight(128).center();
		buttonDisplay.row().padTop(100);
		buttonDisplay.add(debugTestButton).center();
	}

	@Override
	public void update(float dt) { }
}
