package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.math.Vector2;
// LibGDX library references
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;

/** 
 * This class is used for arranging the cards of a player (or dealer) on the table.
 * It stores the {@link GameElement} objects representing the cards of the players
 * hand and sets their position and rotations.
 * 
 * <p>TODO: Correct the position and rotation of the display and the cards so that
 * they are oriented based on the center rather than the bottom left corner for
 * easier layout.
 * <p>TODO: Make this a child of {@link com.badlogic.gdx.scenes.scene2d.Group}, so
 * that it can parent the player cards for easier management of position, rotation,
 * scale, etc.
 * 
 * @author Nikolas Nguyen
 * */
public class BlackjackCardDisplay extends GameElement implements ThreadSafeAsset {
	// Card variables
	public Card priv_card;			// The hidden card for this player
	public Integer priv_cardValue;
	public List<Card> pub_cards;	// The list of public cards for this player
	
	public boolean bLoaded;
	
	// Constructors
	public BlackjackCardDisplay(float x, float y, Stage s) { this(x, y, s, 0.0f); }
	
	/**
	 * This is the basic constructor for setting up the display in screen space and
	 * the stage which it and all its cards will belong to.
	 * 
	 * @param x - the x-coordinate for the display
	 * @param y - the y-coordinate of the display
	 * @param s - the stage that holds the card assets
	 * @param rotation - the rotation of the display
	 */
	public BlackjackCardDisplay(float x, float y, Stage s, float rotation) {
		super(x, y, s);
		pub_cards = new ArrayList<Card>();
		
		setRotation(rotation);
		
		bLoaded = false;
	}
	
	/**
	 * This function sets the private (usually hidden) card to the hand and orients 
	 * it to the appropriate position in the display. Since there is only ever one
	 * privately held card, the new value will override anything stored before.
	 * 
	 * @param cardValue - the integer value of the card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 */
	public void addPrivateCard(Card topCard, int cardValue, boolean display) {
		priv_card = topCard;
		Vector2 screenCoords = localToActorCoordinates(topCard, new Vector2(0, 0));
		priv_card.addAction(Actions.moveBy(screenCoords.x, screenCoords.y, 0.5f));
		
		RunnableAction parentAction = new RunnableAction();
		if(display) {
			parentAction.setRunnable(() -> { 
				addActor(priv_card);
				priv_card.setPosition(0, 0);
				priv_card.setCardValue(cardValue); });
		}
		else {
			parentAction.setRunnable(() -> { 
				addActor(priv_card);
				priv_card.setPosition(0, 0);
			});
		}
		priv_card.addAction(Actions.after(parentAction));

		priv_cardValue = cardValue;
	}
	
	/**
	 * This function adds a public card to the hand and orients it
	 * to the appropriate position in the display. It appends the new card to the
	 * list of visible cards as the player keeps hitting the deck.
	 * 
	 * @param cardValue - the integer value of the card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 */
	public void addPublicCard(Card topCard, int cardValue) {
		Card card = topCard;
		final float x = 256 + (64 * pub_cards.size());
		final float y = 0.0f;
		Vector2 screenCoords = localToActorCoordinates(topCard, new Vector2(x, y));
		card.addAction(Actions.moveBy(screenCoords.x, screenCoords.y, 0.5f));
		
		RunnableAction flipAction = new RunnableAction();
		flipAction.setRunnable(() -> { 
			addActor(card);
			card.setPosition(x, y);
			card.setCardValue(cardValue);
		});
		
		card.addAction(Actions.after(flipAction));
		pub_cards.add(card);
	}
	
	public Integer calculateSum() { 
		if(priv_cardValue == null) return 0;
		if(pub_cards.size() < 1) return 0;
		
		Integer sum = 0;	// The sum value to be returned
		
		int aceCount = 0;	// Count the number of aces for deciding the best sum
		
		// Iterate over each of the player's visible cards
		for(Card card : pub_cards) {
			// Get the value of the card disregarding suit
			Integer pub_val = (card.cardValue % 13) + 1;
			if(pub_val > 10) pub_val = 10;		// Jacks, Queens, and Kings are 10
			
			// Increment aceCount if the card has a value of 1s
			if(pub_val == 1) aceCount++;
			
			sum += pub_val;		// Increment the sum by this card's value
		}
		
		// Calculate the value of the player's hidden card disregarding suit
		Integer priv_val = (priv_cardValue % 13) + 1; 
		if(priv_val > 10) priv_val = 10;		// Jacks, Queens, and Kings are 10
		
		// Increment aceCount if the card has a value of 1s
		if(priv_val == 1) aceCount++;
		// Increment the sum by this card's value
		sum += priv_val;
		
		// Try to get the maximal value from each of the player's aces
		for(int i = 0; i < aceCount; i++)
			if(sum < 11) sum += 10;			// Only add the ace if it doesn't bust
		
		return sum;	// Return the calculated sum
	}
	
	public void flipPrivateCard() { priv_card.setCardValue(priv_cardValue);	}
	
	/**
	 * The update function used to make sure all the assets are properly loaded 
	 * and the game states are updated 
	 * */
	public void update() { if(!isLoaded()) load(); }

	@Override
	public void load() {
		if(priv_card != null && !priv_card.isLoaded()) priv_card.load();
		for(Card c : pub_cards) if(!c.isLoaded()) c.load();
	}
	
	@Override
	public boolean isLoaded() { return bLoaded; }

	@Override
	public void setLoaded(boolean loaded) { bLoaded = loaded; }
}
