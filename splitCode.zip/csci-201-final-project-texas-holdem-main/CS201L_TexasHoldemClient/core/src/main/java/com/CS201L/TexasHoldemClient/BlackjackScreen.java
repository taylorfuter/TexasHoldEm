package com.CS201L.TexasHoldemClient;
//import java.io.IOException;
//import java.net.UnknownHostException;

import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.Viewport;

/**
 * Creates a new screen for the application that runs the logic and rendering for a
 * game of blackjack.
 * 
 * <p><strike>TODO: Add the screen switches between buttons, betting, rounds, and win
 * logic</strike>
 * <p><strike>TODO: Make this the guest game </strike>
 *
 * @author Nikolas Nguyen
 */
public class BlackjackScreen extends BaseScreen {
	BaseScreen prevScreen;
	
	BlackjackCardDisplay dealer;	// The display for the dealer's hand
	BlackjackCardDisplay player;	// The display for the user's hand
	
	// The assets for the background and UI elements
	private GameElement felt;		// The felt background
	private Card topCard;
	
	private TextLabel sumLabel;
	private TextLabel dealerLabel;
	private ButtonElement hit;
	private ButtonElement stay;
	
	private CardPile drawPile;
	
	private boolean bEndGame;
	
	public BlackjackScreen(Viewport viewport, BaseScreen prevScreen) {
		super(viewport);
		this.prevScreen = prevScreen; 
		bEndGame = false;
	}
	
	@Override
	public void createErrorMessageBox(String message) {
		disableUI();
		
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox errMsg = new MessageBox(0, 0, uiStage, "Error", message);
		errMsg.setPosition(x, y, Align.center);
		errMsg.setCancelAction(() -> { 
			BaseGame.setActiveScreen(new BlackjackScreen(viewport, prevScreen));
		});
		errMsg.setCloseAction(() -> {
			BaseGame.setActiveScreen(new BlackjackScreen(viewport, prevScreen));
		});
		errMsg.setOKAction(() -> {
			BaseGame.setActiveScreen(new MenuScreen(viewport));
		});
	}
	
	public void disableUI() {
		if(hit != null) {
			hit.clearActions();
			hit.setVisible(false);
		}
		if(stay != null) {
			stay.clearActions();
			stay.setVisible(false);
		}
	}
	
	@Override
	public void initialize() {
		// Load the background and UI game assets
		felt = new GameElement(0, 0, mainStage);
		felt.loadTexture("felt_blackjack.jpg");			// Load the felt
		felt.toBack();
		
		dealer = new BlackjackCardDisplay(520, 400, mainStage, 0);
		player = new BlackjackCardDisplay(520, 20, mainStage, 0);
		
		topCard = new Card(256, 512, mainStage);

		drawPile = new CardPile();
		
		new Thread(() -> { playGame(); }).start();
	}
	
	public void generateEndGameMenu(String endGameMessage) {
		disableUI();
		if(bEndGame) return;
		
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox endGameMsg = new MessageBox(0, 0, uiStage, "", endGameMessage);
		endGameMsg.setPosition(x, y, Align.center);
		endGameMsg.setCloseAction(() -> { 
			BaseGame.setActiveScreen(new BlackjackScreen(viewport, prevScreen));
		});
		endGameMsg.setOKButtonText("Play Again");
		endGameMsg.setOKAction(() -> { 
				BaseGame.setActiveScreen(new BlackjackScreen(viewport, prevScreen));
		});
		endGameMsg.setCancelAction(() -> { BaseGame.setActiveScreen(prevScreen); });
		endGameMsg.setCancelButtonText("Menu");
		
		bEndGame = true;
	}
	
	public void hit() {
		if(player == null || player.pub_cards.size() < 1) return;

		if(player.calculateSum() < 21) player.addPublicCard(topCard, drawPile.deal());
		topCard = new Card(256, 512, mainStage);
	}
	
	public void stay() {
		disableUI();
		try { Thread.sleep(500); }
		catch(Exception e) { e.printStackTrace(); }
		
		dealer.flipPrivateCard();
		try { Thread.sleep(1000); }
		catch(Exception e) { e.printStackTrace(); }
		
		int sum = dealer.calculateSum();
		dealerLabel = new TextLabel(1500, 625, uiStage, "Dealer Sum: " + sum);
		while(sum < 17) {
			dealer.addPublicCard(topCard, drawPile.deal());
			topCard = new Card(256, 512, mainStage);
			try { Thread.sleep(1500); }
			catch(Exception e) { e.printStackTrace(); }
			
			sum = dealer.calculateSum();
		}
		
		if(sum > player.calculateSum() && sum <= 21) generateEndGameMenu("YOU LOSE!");
		else generateEndGameMenu("YOU WIN!!!");
	}
	
	@Override
	public void update(float dt) {
		if(dealer != null) {
			dealer.update();	// Only try to update if there's a dealer
			if(dealerLabel != null) 
				dealerLabel.setText("Dealer Sum: " + dealer.calculateSum());
		}
		if(player != null) {
			player.update();	// Only update if there's a player
			
			int sum = player.calculateSum();		
			if(sumLabel != null) sumLabel.setText("Sum: " + sum);
			
			if(sum > 21) { generateEndGameMenu("BUST!"); return; }
			if(sum == 21) { generateEndGameMenu("YOU WIN!!!"); return; }
			
		}
		if(topCard != null && !topCard.isLoaded()) topCard.load();
	}
	
	public void playGame() {
		dealer.addPrivateCard(topCard, drawPile.deal(), false);
		topCard = new Card(256, 512, mainStage);
		try { Thread.sleep(500); }
		catch(Exception e) { e.printStackTrace(); }
		
		player.addPrivateCard(topCard, drawPile.deal(), true);
		topCard = new Card(256, 512, mainStage);
		try { Thread.sleep(500); }
		catch(Exception e) { e.printStackTrace(); }
		
		dealer.addPublicCard(topCard, drawPile.deal());
		topCard = new Card(256, 512, mainStage);
		try { Thread.sleep(500); }
		catch(Exception e) { e.printStackTrace(); }
		
		player.addPublicCard(topCard, drawPile.deal());;
		topCard = new Card(256, 512, mainStage);
		try { Thread.sleep(500); }
		catch(Exception e) { e.printStackTrace(); }
		
		sumLabel = new TextLabel(1500, 512, uiStage, "Sum: ");
		hit = new ButtonElement(1500, 325, uiStage);
		hit.setText("Hit");
		hit.setActionPressed(() -> { hit(); });
		
		stay = new ButtonElement(1500, 200, uiStage);
		stay.setText("Stay");
		stay.setActionPressed(() -> { new Thread(() -> { stay(); }).start(); }); 
	}
}