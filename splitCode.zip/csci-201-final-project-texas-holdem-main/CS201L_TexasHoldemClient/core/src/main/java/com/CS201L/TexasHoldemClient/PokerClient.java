package com.CS201L.TexasHoldemClient;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

/**
 * The user's client connection for a poker game. It implements all the necessary
 * functions for the client-side game logic.
 * 
 * <p>TODO: Make sure the opponent and user player setting is correct
 *
 * @author Nikolas Nguyen
 */
public class PokerClient extends ClientMessenger {
	protected Integer playerID;	// The user's unique player ID
	
	public PokerPlayer player;					// A reference to the user's player
	public Map<Integer,PokerPlayer> playerList;	// The list of all players
	
	private LoginScreen loginScreen;
	private PokerScreen screen;	// The screen that this client belongs to
	
	/**
	 * Creates a client connection for communicating game states and player input and
	 * initializes the list of all players in the game (including the user)
	 * 
	 * @param host - the IP address of the host server
	 * @param port - the port that for creating a client socket
	 * @param screen - the screen that instantiates this player
	 */
	public PokerClient(String host, int port, LoginScreen loginScreen) 
			throws UnknownHostException, IOException { 
		super(host, port);
		playerList = java.util.Collections.synchronizedMap(
				new HashMap<Integer,PokerPlayer>());
		this.loginScreen = loginScreen;
	}
	
	@Override
	protected void messageHandler(String msg_command) {
		// Split the command string by whitespace delimiters
		String[] args = msg_command.split("\\s");
		
		// Output the whole command and its split arguments for debugging purposes
		System.out.println("\nMessage from Server: " + msg_command);
		// Process the commands
		if(screen == null) {
			switch(args[0]) {
			case "login":
				if(args[1].equals("success")) loginScreen.setLoginSuccess();
				else if(args[1].equals("err")) {
					loginScreen.createErrorMessageBox("Login failed: \n" +
							msg_command.substring(10));
				}
				break;
			case "signup":
				if(args[1].equals("success")) {
					loginScreen.createSignupMessageBox("Signup successful!");
					BaseGame.setActiveScreen(loginScreen);
				}
				else if(args[1].equals("err")) {
					loginScreen.createErrorMessageBox("Signup failed: \n" +
							msg_command.substring(11));
					BaseGame.setActiveScreen(loginScreen);
				}
				break;
			}
		}
		else {
			switch(args[0]) {
			case "accept":	// The server accepted the connection and issued an ID
				try {
					if(player != null) { 
						System.out.println("p not null"); 
						System.out.println("\targ: " + args[1]);
						break;
					}
					
					Integer id = Integer.parseInt(args[1]);
					System.out.println("\t - ID: " + id);
					playerID = id;					// Set the user's player ID
					addPlayer(id);					// Add this player to the list
					
					System.out.println("Assigning player " + id);
					player = playerList.get(id);	// Set the user to this player
					
					screen.addCommunity();	// Add the community since there's a game
					screen.addPlayer();	// Add this player to the screen
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in accept command"); 
				}
				break;
			case "betting_pot":
				try {
					if(args.length == 2) {
						Integer pot = Integer.parseInt(args[1]);
						screen.playerBetHUD.setRoundPotValue(pot);
					}
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in deal command");
				}
				break;
			case "burn":
				screen.community.dealBurn();
				break;
			case "deal":	// The server has dealt a card to some player
				try {
					Integer id = Integer.parseInt(args[1]);	// Find out which player
					System.out.println("\t - ID: " + id);
					
					/* 
					 * If the server has dealt the user a card, only process the command
					 * that specifies our card value. The server will echo all clients
					 * that the user has been dealt a private card "deal [id]", but will
					 * only send the user the value of the card. "deal [id] [cardvalue]"
					 * */
					if(id == playerID && (args.length == 3))
					{
						Integer card = Integer.parseInt(args[2]);
						System.out.println("\t - Card: " + card);
						player.dealCard(card);		// Deal the card to the user's hand
						screen.dealPlayer(card);	// Update the screen
					}
					else if (id != playerID && playerList.containsKey(id)) {
						playerList.get(id).dealPrivateCard();	// Deal the private card
						screen.dealOpponent(id);				// Update the screen
					}
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in deal command");
				}
				break;
			case "dealer_button":
				try {
					// Make sure there are enough cards (3) for the flop
					if(args.length == 2) {
						Integer id = Integer.parseInt(args[1]);
						if(id == playerID) screen.setDealerPlayer();
						else screen.setDealerOpponent(id);
					}
					else System.out.println("Unknown server message");
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in flop command");
				}
				break;
			case "flop":	// The server has dealt the flop
				try {
					// Make sure there are enough cards (3) for the flop
					if(args.length == 4)
						screen.dealFlop(Integer.parseInt(args[1]), Integer.parseInt(args[2]),
								Integer.parseInt(args[3]));
					else System.out.println("Unknown server message");
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in flop command");
				}
				break;
			case "fold":
				try {
					// Make sure there are enough cards (3) for the flop
					if(args.length == 2) {
						Integer id = Integer.parseInt(args[1]);
						if(id != playerID) screen.foldOpponent(id);
						else screen.foldPlayer();
					}
					else System.out.println("Unknown server message");
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in flop command");
				}
				break;
			case "lose":
				screen.createEndGameMessageBox("You LOSE!");
				break;
			case "min_raise":
				try {
					if(args.length == 2) {
						Integer minRaise = Integer.parseInt(args[1]);
						screen.playerBetHUD.setMinRaise(minRaise);
					}
				}
				catch(NumberFormatException e) {
					System.out.println("Error in min_raise command");
				}
				break;
			case "msg":	// The server has sent the client a text message
				System.out.println("Message from server: " + msg_command.substring(4));
				break;
			case "opt":
				boolean bRaise = false;
				boolean bCall = false;
				boolean bCheck = false;
				boolean bFold = false;
				for(int i = 1; i < args.length; i++) {
					if(screen.playerBetHUD == null) break;
					
					screen.enableBettingHUD();
					
					switch(args[i]) {
					case "call": 
						screen.playerBetHUD.setCall();
						bCall = true;
						break;
					case "check": 
						screen.playerBetHUD.setCheck();
						bCheck = true; 
						break;
					case "fold": bFold = true; break;
					case "raise": bRaise = true; break;
					}
				}
				
				if(!bRaise) screen.playerBetHUD.disableBet();
				if(!bCall && !bCheck) screen.playerBetHUD.disableCheck();
				if(!bFold) screen.playerBetHUD.disableFold();
								
				break;
			case "player":	// The server has indicated that there's another player
				try {
					Integer id = Integer.parseInt(args[1]);
					System.out.println("\t - ID: " + id);
					addPlayer(id);
					if(id != playerID)				// Ignore if it's the user's player
						screen.addOpponent(id);	// Add a new player to the opponents
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in player command");
				}
				break;
			case "pot":
				try {
					if(args.length == 2 && screen.playerBetHUD != null)
						screen.playerBetHUD.setPotValue(Integer.parseInt(args[1]));
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in player command");
				}
				break;
			case "reveal":	// The server has revealed an opponent's cards
				try {
					// Make sure it has the right number of arguments
					if(args.length == 4) {
						screen.revealOpponent(Integer.parseInt(args[1]), 
								Integer.parseInt(args[2]), Integer.parseInt(args[3]));
					}
					else System.out.println("Error in reveal command");
				}
				catch(NumberFormatException e) {
					System.out.println("Error in reveal command");
				}
				break;
			case "river":	// The server has dealt the river
				try {
					// Make sure the server dealt a card value
					if(args.length == 2) {
						screen.dealRiver(Integer.parseInt(args[1]));	// Update
					}
					else System.out.println("Error in river command");
				}
				catch(NumberFormatException e) {
					System.out.println("Error in river command");
				}
				break;
			case "set_wallet":
				try {
					// Make sure the server dealt a card value
					if(args.length == 2 && screen.playerBetHUD != null)
						screen.playerBetHUD.setWallet(Integer.parseInt(args[1]));
					else System.out.println("Error in set_wallet command");
				}
				catch(NumberFormatException e) {
					System.out.println("Error in set_wallet command");
				}
				break;
			case "turn":	// The server has dealt the turn
				try {
					// Make sure the server dealt a card value
					if(args.length == 2)
						screen.dealTurn(Integer.parseInt(args[1]));	// Update
					else System.out.println("Unknown server message");
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in dealer command");
				}
				break;
			case "update_wallet":
				try {
					if(args.length == 2 && screen.playerBetHUD != null)
						screen.playerBetHUD.updateWallet(Integer.parseInt(args[1]));
					else System.out.println("Unknown server message");
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in dealer command");
				}
				break;
			case "win":
				try {
					if(args.length > 1) {
						Integer id = Integer.parseInt(args[1]);
						Integer winnings = Integer.parseInt(args[2]);
						if(id == playerID)
							screen.createEndGameMessageBox("You won $" + winnings + "!!!");
					}
				}
				catch(NumberFormatException e) { 
					System.out.println("Error in dealer command");
				}
				break;
			default:
				System.out.println("Unknown server message: " + args[0]);
			}
		}	
	}
	
	/**
	 * Adds a player to the player list but enforces that it is of the type
	 * {@link PokerPlayer}
	 * 
	 * @param id - the unique ID of the player
	 */
	public void addPlayer(Integer id) { playerList.put(id, new PokerPlayer()); }
	
	public LoginScreen getLoginScreen() { return loginScreen; }
	
	public PokerScreen getPokerScreen() { return screen; }
	
	public boolean hasPokerScreen() { return (screen != null); }
	
	public void setPokerScreen(PokerScreen screen) { this.screen = screen; }
}