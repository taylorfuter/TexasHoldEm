package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A class for initializing a deck of cards and randomly selecting from them. It
 * allows for the addition of multiple decks for certain card games (e.g. rummy)
 * 
 * @author Nikolas Nguyen
 * */
public class CardPile {
	private Random rand;			// Random number generator
	private List<Integer> cardList;	// The list that stores the remaining cards
	
	/** Basic constructor which adds a single deck of cards to the pile */
	public CardPile() {
		rand = new Random();					//Initialize the member variables
		cardList = new ArrayList<Integer>();
		
		add_deck();	// Add a deck to the pile
	}
	
	/** Adds a new deck to the pile by inserting the 52 card values */
	public void add_deck() { for(int i = 0; i < 52; i++) cardList.add(i); }
	
	/** @return The random card that was dealt */
	public Integer deal() { return cardList.remove(rand.nextInt(cardList.size())); }
}
