package com.CS201L.TexasHoldemClient;

// LibGDX library references
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.Viewport;

/** 
 * This abstract class implements the {@link com.badlogic.gdx.Screen} and
 * {@link com.badlogic.gdx.InputProcessor} for creating a display and listening for
 * user input. This declares all the features needed for starting a screen game
 * flow. Connecting the screens together through functions called by events or user
 * input allows for following game logic to different game states. (e.g. Starting at 
 * a Login UI Screen -> Lobby UI Screen -> Gameplay Screen)
 * 
 * <p>TODO: Create the previous screen returning functionality to this base class
 * since {@link PokerScreen} {@link LoginScreen} {@link BlackjackScreen} and probably
 * other future screens use this for returning to the last GUI menu for various
 * reasons. Include the member {@code private BaseScreen prevScreen} and a function
 * like {@code public void screenReturn()} for calling the screen back to the last
 * one. The member should be initialized in the constructor (see the current {@link 
 * PokerClient} constructor) and maybe be able to take a null value.
 * 
 * @author Nikolas Nguyen 
 * */
public abstract class BaseScreen implements Screen, InputProcessor {
	protected Stage mainStage;	// The main stage for rendering
	protected Stage uiStage;	// The stage used to render HUD and UI elements
	
	protected Viewport viewport;
	
	/** The basic constructor for initializing the stages for rendering */
	public BaseScreen(Viewport viewport) {
		mainStage = new Stage();
		uiStage = new Stage();
		
		this.viewport = viewport;
		mainStage.setViewport(viewport);
		uiStage.setViewport(viewport);
		viewport.apply();
		
		// Call the initialize function which is meant to be overriden by children
		initialize();
	}
	
	// Main Functions
	/** Initializes all the resources needed by this screen */
	public abstract void initialize();
	
	/** 
	 * Updates all the screen resources as needed by the game engine. Called before
	 * each render.
	 * 
	 * @param dt - the elapsed time in seconds
	 *  */
	public abstract void update(float dt);
	
	public void createErrorMessageBox(String message) {
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox errMsg = new MessageBox(0, 0, uiStage, "Error", message);
		errMsg.setPosition(x, y, Align.center);
	}
	
	@Override
	public void show() { 
		// Make sure the screen is in focus for user input
		InputMultiplexer im = (InputMultiplexer)Gdx.input.getInputProcessor();
		im.addProcessor(this);
		im.addProcessor(uiStage);
		im.addProcessor(mainStage);
	}
	
	/** 
	 * This function is responsible for rendering all the assets listed in the main
	 * rendering stage and the UI/HUD stage. Before it clears the screen buffer and
	 * renders, it updates all the {@link com.badlogic.gdx.scenes.scene2d.Actor} 
	 * objects listed in each stage then all the screen-specific resources through
	 * {@link update()}.
	 * 
	 * <p>This function is invoked by the libGDX application for every frame.
	 * 
	 * @see {@link GameElement}.act() - this function is called by the stages to
	 * update the assets' game state
	 * 
	 * @param dt - the elapsed time in seconds between the last frame render
	 * */
	@Override
	public void render(float dt) { 
		uiStage.act(dt);
		mainStage.act(dt);
		
		update(dt);	// Call the update function to update the resources
		
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		mainStage.draw();
		uiStage.draw();
	}

	/**
	 * This function is called whenever the window is resized
	 * 
	 * <p>TODO: Properly handle the resizing of UI elements for better display
	 * 
	 * @param width - the new width of the application window
	 * @param height - the new height of the application window
	 */
	@Override
	public void resize(int width, int height) { }
	
	/** 
	 * Called when the current screen is paused
	 */
	@Override
	public void pause() { }
	
	/** 
	 * Called when the current screen resumes activity
	 */
	@Override
	public void resume() { }
	
	/** Hide this screen from the user and drop the focus from user input */
	@Override
	public void hide() {
		// Remove user input focus
		InputMultiplexer im = (InputMultiplexer)Gdx.input.getInputProcessor();
		im.removeProcessor(mainStage);
		im.removeProcessor(uiStage);
		im.removeProcessor(this);
	}
	
	@Override
	public void dispose() {	 }
	
	/* 
	 * Implement default functions for the com.badlogic.gdx.InputProcessor interface
	 * so that children classes only need to override the input functions they need 
	 * */
	public boolean keyDown(int keycode) { return false; }
	public boolean keyUp(int keycode) { return false; }
	public boolean keyTyped(char c) { return false; }
	public boolean mouseMoved(int screenX, int screenY) { return false; }
	public boolean scrolled(int amount) { return false; }
	public boolean touchDown(int screenX, int screenY, int pointer, int button) 
	{ return false; }
	public boolean touchDragged(int screenX, int screenY, int pointer) { return false; }
	public boolean touchUp(int screenX, int screenY, int pointer, int button)
	{ return false; }
}
