package com.CS201L.TexasHoldemClient;

import java.io.IOException;
import java.net.UnknownHostException;

public class LoginConnection extends ClientMessenger {
	LoginScreen screen;
	
	public LoginConnection(String host, int port, LoginScreen screen) 
			throws UnknownHostException, IOException {
		super(host, port);
		
		this.screen = screen;
	}
	
	@Override
	protected void messageHandler(String msg_command) {
		String[] args = msg_command.split("\\s");
		
		// Output the whole command and its split arguments for debugging purposes
		System.out.println("Message from Server: " + msg_command);
		for(int i = 0; i < args.length; i++) System.out.println("\t" + args[i]);
		
		if(!args[0].equals("login")) return;
		
		// Process the commands		
		switch(args[1])
		{
		case "success":
			screen.setLoginSuccess();
		}
	}
}