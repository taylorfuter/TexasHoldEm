package com.CS201L.TexasHoldemClient;

// Java library references
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
 * This class handles the client connection to the server. It holds the socket and
 * its respective input and output streams. This thread is used to constantly read
 * the messages sent to it by the server and handle them as a set of commands.
 * Currently it constantly echoes user input to the server.
 * 
 * <p>TODO: Create a safe cleanup function to close resources
 * <p>TODO: Separate the reading function so that other functions can be implemented
 * by children classes (e.g. chat functions or individual line reading
 *
 * @author Nikolas Nguyen
 */
public class ClientMessenger extends Thread {
	private Socket s;
	private BufferedReader br;
	private PrintWriter pw;
	
	/**
	 * Creates a basic client-server connection for communicating commands
	 * 
	 * @param host - the IP address of the host server
	 * @param port - the port designated for the client-server socket
	 */
	public ClientMessenger(String host, int port) 
			throws UnknownHostException, IOException {
		System.out.println("Starting Client");
		
		// Create the socket which requests a connection from the host server
		s = new Socket(host, port);
		
		System.out.println("Client Started");
		System.out.println("Client port: " + s.getLocalPort());
		
		// Create the input and output stream resources
		br = new BufferedReader(new InputStreamReader(s.getInputStream()));
		pw = new PrintWriter(s.getOutputStream(), true); // Auto-flush
	}
	
	public void close() {
		// Once the client is closed, safely clean the client resources
		try { 
			br.close();
			pw.close();
			if(!s.isClosed()) s.close();
		}
		catch (IOException e) { e.printStackTrace(); }
	}
	
	/** 
	 * Sends a message to the server through the socket output stream
	 * 
	 * @param msg - the message to be sent
	 */
	public void echoServer(String msg) { 
		if(s.isConnected()) {
			System.out.println("Message to server: " + msg);
			pw.println(msg);
		}
	}
	
	/** 
	 * Called by the message reading thread to process commands sent by the server
	 * through the socket's input stream. This should handle all the commands
	 * required to run the client game.
	 * 
	 * @param msg_command - the string command received from the server input
	 * */
	protected void messageHandler(String msg_command) {
		return;
	}
	
	/**
	 * Run the client connection by starting a new thread that echoes all user input
	 * through the console to the server and handles messages through this instance 
	 * of a thread.
	 */
	@Override
	public void run() {
		System.out.println("Start!");
		new Thread(() -> {								// Create a new thread
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);	// Read the console input
			String msg = "";
			while(true) {								// Continuously read
				msg = scanner.nextLine();
				echoServer(msg);						// Echo to the server
			}
		}).start();										// Start this thread
		
		System.out.println("Starting reading thread!");
		String msg_server = "";
		while(!msg_server.equals("quit"))	// Only stop from the "quit" command
		{
			// Make sure there is still a connection
			if(!s.isConnected()) { 
				System.out.println("Connection broken");
				break;
			}
			
			// Try to read the next line
			try {
				msg_server = br.readLine();
				messageHandler(msg_server);
			} 
			catch (SocketException e) {
				System.out.println("Connection broken");
				break;
			}
			catch (IOException e) { e.printStackTrace(); }
		}
		
		close();
	}

	public boolean isConnected() { return s.isConnected(); }
}
