package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.utils.Align;

public class MessageBox extends DialogBox {
	String title;
	String message;
	Table displayTable;
	
	private ButtonElement okButton;
	private ButtonElement cancelButton;
	private TextLabel titleLabel;
	private TextLabel messageLabel;
	
	public MessageBox(float x, float y, Stage s) { this(x, y, s, "Message Box", ""); }

	public MessageBox(float x, float y, Stage s, String title, String message) {
		super(x, y, s);
		
		this.title = title;
		this.message = message;
		
		okButton = new ButtonElement(0, 0, getStage(), () -> { close(); });
		okButton.setText("OK");
		okButton.setScale(0.75f);
		
		cancelButton = new ButtonElement(0, 0, getStage(), () -> { close(); });
		cancelButton.setText("Cancel");
		cancelButton.setScale(0.75f);
		
		titleLabel = new TextLabel(0, 0, getStage(), title);
		titleLabel.setScale(0.5f);
		
		messageLabel = new TextLabel(0, 0, getStage(), message);
		messageLabel.setScale(0.75f);
		
		refreshTable();
		
		if(texture == null) texture = GameAssets.defaultDialogBoxStyle;
	}
	
	@Override
	protected void close() {
		displayTable.setVisible(false);
		removeActor(displayTable);

		super.close();
	}

	protected void refreshTable() {		
		if(displayTable == null) {
			displayTable = new Table();
			addActor(displayTable);
		}
		else displayTable.clear();

		displayTable.pad(8);
		
		displayTable.row().colspan(2);
		displayTable.add(titleLabel).left();
		
		displayTable.row().colspan(2).pad(64, 64, 64, 64);
		displayTable.add(messageLabel).left();
		
		displayTable.row();
		displayTable.add(okButton).right();
		displayTable.add(cancelButton).left();
		
		displayTable.validate();
		
		float width = 0;
		float height = 0;
		for(int i = 0; i < displayTable.getColumns(); i++)
			width += displayTable.getColumnWidth(i);
		for(int i = 0; i < displayTable.getRows(); i++) 
			height += displayTable.getRowHeight(i);
		setSize(width, height);
		setOrigin(Align.center);
		
		displayTable.toFront();
		
		displayTable.setPosition(getOriginX() + 16, getOriginY() + 16, Align.center);
		
	}
	
	// Get-Set Functions
	
	public String getMessage() { return message; }
	
	public TextLabel getMessageLabel() { return messageLabel; }
		
	public void setCancelAction(ButtonElement.ButtonAction action) {
		cancelButton.setActionPressed(() -> { action.activate(); close(); });
	}
	
	public void setCancelButtonText(String text) {
		cancelButton.setText(text);
		refreshTable();
	}
	
	public void setCloseAction(ButtonElement.ButtonAction action) {
		closeButton.setActionPressed(() -> { action.activate(); close(); });
	}
	
	public void setMessage(String message) {
		this.message = message;
		if(messageLabel != null) messageLabel.setText(message);
	}
	
	public void setOKAction(ButtonElement.ButtonAction action) {
		okButton.setActionPressed(() -> { action.activate(); close(); });
	}
	
	public void setOKButtonText(String text) {
		okButton.setText(text);
		refreshTable();
	}
	
	public void setTitle(String title) {
		this.title = title;
		if(titleLabel != null) titleLabel.setText(title);
	}
	
	public void setMessageBoxStyle(NinePatchDrawable background) {
		texture = background;
	}
}
