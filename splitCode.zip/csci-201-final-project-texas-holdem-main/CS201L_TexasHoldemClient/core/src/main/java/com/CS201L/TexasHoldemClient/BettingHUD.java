package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.Align;

/**
 * This class organizes the GUI elements used by the user for betting
 * 
 * <p>TODO: Create a text label for the current bet and current pot
 * <p>TODO: Fix the alignment of the buttons
 * 
 * @author Nikolas Nguyen
 */
public class BettingHUD extends DraggableElement implements ThreadSafeAsset {
	boolean bLoaded;
	
	TextLabel potLabel;
	TextLabel roundPotLabel;
	TextLabel betLabel;
	TextLabel minRaiseLabel;
	TextLabel playerBetLabel;
	TextLabel walletLabel;
	
	int pot = 0;
	int bet = 0;
	int minRaise = 0;
	int playerBet = 0;
	int wallet = 0;
	boolean bFolded = false;
	
	ButtonElement betButton;
	ButtonElement checkButton;
	ButtonElement foldButton;
	
	TextEntry betField;
	
	ChipDisplay playerWallet;
	ChipDisplay playerPot;
	
	PokerClient client;
	
	public BettingHUD(float x, float y, Stage s) { this(x, y, s, null); }
	
	public BettingHUD(float x, float y, Stage s, PokerClient client) {
		super(x, y, s);
		this.client = client;
		bLoaded = false;
	}
	
	public void call() {
		if(client != null && (bet - playerBet) < wallet) client.echoServer("call");
		System.out.println("Called!");
		disableInput();
	}
	
	public void check() {
		if(client != null) client.echoServer("check");
		disableInput();
	}
	
	public void fold() {
		disableBet();
		disableCheck();
		disableFold();
		
		if(client != null) client.echoServer("fold");
		disableInput();
	}
	
	public void raise() {
		if(betField == null) return;
		
		betField.setErrorMode(false);
		String betEntry = betField.getText();
		try {
			int raise = Integer.parseInt(betEntry);
			if(raise < minRaise)
				betField.flagError("The minimum raise is " + minRaise);
			else if(((raise + bet) - playerBet) > wallet)
				betField.flagError("Raise exceeds your funds");
			else if(client != null) {
				client.echoServer("raise " + raise);
				disableInput();
			}
		}
		catch(NumberFormatException e) {
			betField.flagError("Please enter a valid number");
		}
		betField.setText("");
	}

	public void disableBet() {
		//betField.setVisible(false);
		
		betButton.clearActionPressed();
		betButton.setColor(Color.LIGHT_GRAY);
	}
	
	public void disableCheck() {
		checkButton.clearActionPressed();
		checkButton.setColor(Color.LIGHT_GRAY);
	}
	
	public void disableFold() {
		foldButton.clearActionPressed();
		foldButton.setColor(Color.LIGHT_GRAY);
		foldButton.setFontColor(Color.FIREBRICK);
	}
	
	public void disableInput() {
		setDraggability(false);
		//if(betField != null) betField.setColor(Color.GRAY);
		if(betButton != null) betButton.clearActionPressed();
		if(checkButton != null) checkButton.clearActionPressed();
		if(foldButton != null) foldButton.clearActionPressed();
		client.getPokerScreen().disableBettingHUD();
	}
	
	public void enableInput(boolean raise, boolean check, boolean call, boolean fold) {
		setDraggability(true);
		if(betField != null && raise) {
			betField.setVisible(true);
			//betField.setColor(Color.WHITE);
			betField.toFront();
		}
		if(betButton != null && raise) betButton.setActionPressed(() -> { raise(); });
		
		if(foldButton != null && fold) foldButton.setActionPressed(() -> { fold(); });
	}
	
	@Override
	public void load() {
		potLabel = new TextLabel(0, 0, getStage(), "Pot Value: $" + pot);
		potLabel.setScale(0.6f);
		roundPotLabel = new TextLabel(0, 0, getStage(), "Round Pot: $0");
		roundPotLabel.setScale(0.6f);
		betLabel = new TextLabel(0, 0, getStage(), "Current Bet: $" + bet);
		betLabel.setScale(0.6f);
		minRaiseLabel = new TextLabel(0, 0, getStage(), "Min Raise: $" + minRaise);
		minRaiseLabel.setScale(0.6f);
		playerBetLabel = new TextLabel(0, 0, getStage(), "Your Bet: $" + playerBet);
		playerBetLabel.setScale(0.6f);
		walletLabel = new TextLabel(0, 0, getStage(), "Wallet: $" + wallet);
		walletLabel.setScale(0.6f);
		
		TextField.TextFieldStyle fieldStyle = new TextField.TextFieldStyle(
				GameAssets.defaultFont, Color.BLACK, null, null,
				GameAssets.loadNinePatch("textfield_9patch.png"));
		
		// Initialize a field for the user to enter their username
		betField = new TextEntry(0, 0, getStage(), fieldStyle);
		betField.getTextField().setMaxLength(6);
		betField.getTextField().setFocusTraversal(true);
		betField.setWidth(300);
		betField.setScale(0.75f);
		
		betButton = new ButtonElement(0, 0, getStage(),	() -> { raise(); });
		betButton.createTextLabel("Bet!", Color.BLACK);
		checkButton = new ButtonElement(0, 0, getStage(), () -> { check(); });
		checkButton.createTextLabel("Check!", Color.BLACK);
		foldButton = new ButtonElement(0, 0, getStage(), () -> { fold(); });
		foldButton.createTextLabel("Fold!", Color.RED);
		
		Table buttonDisplay = new Table();
		addActor(buttonDisplay);
		
		buttonDisplay.pad(32);
		
		buttonDisplay.row().colspan(2);
		buttonDisplay.add(potLabel).left();
		buttonDisplay.row().colspan(2);
		buttonDisplay.add(roundPotLabel).left();
		buttonDisplay.row().colspan(2);
		buttonDisplay.add(betLabel).left();
		buttonDisplay.row().colspan(2);
		buttonDisplay.add(minRaiseLabel).left();
		buttonDisplay.row().colspan(2);
		buttonDisplay.add(playerBetLabel).left().padTop(16);
		buttonDisplay.row().colspan(2);
		buttonDisplay.add(walletLabel).left();
		
		buttonDisplay.row();
		buttonDisplay.add(betField).prefWidth(128);
		betField.setPosition(-50, -50, Align.center);
		buttonDisplay.add(betButton).prefWidth(128).prefHeight(64);
		
		buttonDisplay.row().right();
		buttonDisplay.add(checkButton).prefWidth(128).prefHeight(64).right();
		buttonDisplay.add(foldButton).prefWidth(128).prefHeight(64).right();
		
		buttonDisplay.validate();
		
		float width = 0;
		float height = 0;
		for(int i = 0; i < buttonDisplay.getColumns(); i++)
			width += buttonDisplay.getColumnWidth(i);
		for(int i = 0; i < buttonDisplay.getRows(); i++) 
			height += buttonDisplay.getRowHeight(i);
		setSize(width + 64, height + 64);
		setOrigin(Align.center);
		buttonDisplay.toFront();
		
		buttonDisplay.setPosition(getOriginX() + 16, getOriginY() + 16, Align.center);
		
		if(texture == null) texture = GameAssets.defaultDialogBoxStyle;
		
		bLoaded = true;
	}
	
	public void update() { if(!isLoaded()) load(); }

	// Get-Set Functions
	
	public int getWallet() { return wallet; }
		
	@Override
	public boolean isLoaded() { return bLoaded; }

	public void setCall() { 
		System.out.println("Call to setCall()");
		checkButton.setText("Call");
		checkButton.setActionPressed(() -> { call(); });
	}
	
	public void setCheck() { 
		System.out.print("Call to setCheck()");
		checkButton.setText("Check");
		checkButton.setActionPressed(() -> { check(); });
	}
	
	public void setCurrentBet(int bet) { 
		this.bet = bet;
		betLabel.setText("Current Bet: $" + bet);
	}
	
	public void setMinRaise(int minRaise) {
		this.minRaise = minRaise;
		minRaiseLabel.setText("Min Raise: $" + minRaise);
	}
	
	public void setPotValue(int pot) { 
		this.pot = pot;
		potLabel.setText("Pot Value: $" + pot);
	}
	
	public void setRoundPotValue(int roundPot) {
		if(roundPotLabel != null) roundPotLabel.setText("Round Pot: $" + roundPot);
	}
	
	public void setWallet(int wallet) {
		this.wallet = wallet;
		walletLabel.setText("Wallet: $" + wallet);
	}

	public void updateWallet(int value) { setWallet(wallet + value); }
	
	@Override
	public void setLoaded(boolean loaded) { bLoaded = loaded; }
}
