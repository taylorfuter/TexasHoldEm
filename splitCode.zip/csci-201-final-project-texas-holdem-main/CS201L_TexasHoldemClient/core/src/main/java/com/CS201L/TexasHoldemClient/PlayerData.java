package com.CS201L.TexasHoldemClient;

public class PlayerData {
	String username;
	int wallet;
	
	public PlayerData(String username, int wallet) {
		this.username = username;
		this.wallet = wallet;
	}
	
	public String getUsername() { return username; }
	public int getWallet() { return wallet; }
}
