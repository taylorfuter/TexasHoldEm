package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Actor;
// LibGDX library references
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.utils.TransformDrawable;
import com.badlogic.gdx.utils.Align;

/**
 * This function creates a button from a game element that can be set to trigger a
 * specific action when pressed and released. This is encapsulated by the internal
 * public interface, {@link ButtonAction} whose sole function, {@code activate()}
 * is called by the user's interaction with the button. This function can be set
 * using lambda expressions for basic button-triggered events.
 *
 * <p>TODO: Consider merging {@link com.badlogic.gdx.scenes.scene2d.ui.Button}
 *
 * @author Nikolas Nguyen
 */
public class ButtonElement extends GameElement {
	protected ButtonElement self;	// Used for accessing this in the input listener
	
	protected ButtonAction actionPressed;	// The action to run when pressed
	protected ButtonAction actionReleased;	// The action to run when released
	
	protected GameAssets.ButtonStyle buttonStyle;
	
	protected TextLabel label;
	
	private boolean bActivated;	// Used for disabling the button
	
	/**
	 * Creates a button with a press functionality, but with an empty action. It will
	 * still listen for input and show whether it's being pressed, but will not run
	 * any function on pressing. To add a function for the button to be pressed,
	 * either use the constructor specifying the {@link ButtonAction} to use or use
	 * the set function for the instantiated ButtonElement
	 *  
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 */
	public ButtonElement(float x, float y, Stage s) {
		this(x, y, s, () -> {}, () -> {});
	}
	
	/**
	 * Creates a button with a press functionality that triggers the
	 * {@code action.activate()} method when pressed.
	 *  
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 * @param action - the action to perform on pressing this button
	 */	
	public ButtonElement(float x, float y, Stage s, ButtonAction action) {
		this(x, y, s, action, () -> {});
	}
	
	/**
	 * Creates a button with a press functionality that triggers the
	 * {@code onPress.activate()} method when pressed and the
	 * {@code onRelease.activate()} when released
	 *  
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 * @param action - the action to perform on pressing this button
	 */	
	public ButtonElement(float x, float y, Stage s, ButtonAction onPress,
			ButtonAction onRelease) {
		this(x, y, s, onPress, onRelease, GameAssets.defaultButtonStyle);
	}
	
	public ButtonElement(float x, float y, Stage s, ButtonAction onPress,
			ButtonAction onRelease, GameAssets.ButtonStyle style) {
		super(x, y, s);
		actionPressed = onPress;
		actionReleased = onRelease;
		
		bActivated = true;
		
		buttonStyle = style;
		texture = buttonStyle.up;
		
		self = this;
		addListener(new InputListener() {
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
				if(buttonStyle.over != null) texture = buttonStyle.over;
			}
			public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
				if(buttonStyle.over != null) texture = buttonStyle.up;
			}
			public boolean touchDown(InputEvent event, float eventOffsetX, 
					float eventOffsetY, int pointer, int button) {
				if(buttonStyle.down != null) texture = buttonStyle.down;
				
				self.actionPressed.activate();	// Run the press action
				
				System.out.println("Clicked at position: (" + eventOffsetX + ", " + eventOffsetY + ")");
				
				return true; // Return true since we want to track the release
			}
			public void touchUp(InputEvent event, float eventOffsetX, float eventOffsetY,
					int pointer, int button) {
				if(buttonStyle.down != null) texture = buttonStyle.up;
				self.actionReleased.activate();	// Run the release action
			}
		});
	}
	
	public void createTextLabel(String text) {
		createTextLabel(text, GameAssets.defaultLabelStyle);
	}
	
	public void createTextLabel(String text, BitmapFont font) {
		createTextLabel(text, new Label.LabelStyle(font, Color.BLACK));
	}
	
	public void createTextLabel(String text, Color color) {
		createTextLabel(text, new Label.LabelStyle(GameAssets.defaultFont, color));
	}
	
	public void createTextLabel(String text, LabelStyle style) {
		label = new TextLabel(0, 0, getStage(), text, style);
		addActor(label);
		setSize(label.getWidth() + 64, label.getHeight() + 32);
		label.setOrigin(Align.center);
		label.setPosition(32, 16);
		label.toFront();
	}
	
	// Get-Set Functions
	
	/** Make the button's do no action when pressed */
	public void clearActionPressed() { actionPressed = () -> {}; }
	
	/** Make the button's do no action when released */
	public void clearActionReleased() { actionReleased = () -> {}; }
		
	/** @return The action that is triggered when this button is pressed */
	public ButtonAction getActionPressed() { return actionPressed; }
	
	/** @return The action that is triggered when this button is released */
	public ButtonAction getActionReleased() { return actionReleased; }
	
	public boolean isActivated() { return bActivated; }
	
	/** @param actionPressed - the action to trigger when pressing the button */
	public void setActionPressed(ButtonAction actionPressed) {
		this.actionPressed = actionPressed;
	}
	
	/** @param actionReleased - the action to trigger when releasing the button */
	public void setActionReleased(ButtonAction actionReleased) {
		this.actionReleased = actionReleased;
	}
	
	public void setActivated(boolean bActivated) { this.bActivated = bActivated; }
	
	@Override
	public void setColor(Color color) {
		super.setColor(color);
		if(label != null) label.setColor(color);
	}
	
	public void setFontColor(Color color) { if(label != null) label.setColor(color); }
	
	public void setIcon(TransformDrawable icon) {
		GameElement iconElement = new GameElement(0, 0, getStage());
		iconElement.texture = icon;
		
		float width = icon.getMinWidth() + 32;
		float height = icon.getMinHeight() + 32;
		setSize(width, height);
		setOrigin(width / 2, height / 2);
		
		addActor(iconElement);
		iconElement.toFront();
	}
	
	public void setIcon(GameElement icon) {
		float width = icon.getWidth() + 32;
		float height = icon.getHeight() + 32;
		if(label == null) {
			setSize(width, height);
			setOrigin(Align.center);
		}
		
		addActor(icon);
		icon.setPosition(16, 16);
		icon.toFront();
	}
	
	public void setText(String text) {
		if(label == null) { createTextLabel(text); return; }
		
		label.setText(text);
		setSize(label.getWidth() + 64, label.getHeight() + 32);
		label.setOrigin(Align.center);
		label.setPosition(32, 16);
	}
	
	/**
	 * This basic interface contains only the {@code activate()} function for use by
	 * buttons when either pressed or released. It's public and mainly meant for use
	 * with basic lambda expressions for quickly writing button-triggered events like
	 * screen switching. It is essentially the same as {@link java.lang.Runnable};
	 * however this provides a way for the compiler to enforce type.
	 * 
	 * @see {@link ButtonElement} for the use of {@code ButtonAction} objects as
	 * triggered events.
	 * */
	public interface ButtonAction {
		/** The function called by the button when either pressed or released */
		public void activate();
	}
}
