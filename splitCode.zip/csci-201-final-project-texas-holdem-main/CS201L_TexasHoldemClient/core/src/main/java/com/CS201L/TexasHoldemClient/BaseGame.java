package com.CS201L.TexasHoldemClient;

// LibGDX library references
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;

/**
 * This abstract class is meant to organize the shared features of all games by
 * establishing an input processor and a way to initialize a screen 
 * */
public abstract class BaseGame extends Game {
	protected static BaseGame game;		// Instantiate only one game
	
	/** This basic constructor simply sets the single static instance of the game */
	public BaseGame() { game = this; }
	
	/** This method is used to set up the resources needed for the game. */
	@Override
	public void create() {
		// Instantiate and set an InputMultiplexer for processing user input
		InputMultiplexer im = new InputMultiplexer();
		Gdx.input.setInputProcessor(im);
	}
		
	/**
	 * Set the active screen of the game to the given {@link BaseScreen}. This
	 * function is needed to start a display and run the game logic flow.
	 * 
	 * @param s - the screen to use for the game
	 * */
	public  static void setActiveScreen(BaseScreen s) { 
		int width = Gdx.graphics.getWidth();
		int height = Gdx.graphics.getHeight();
		float ratio = width / height;
		if(ratio > 2) width = height * 2;
		else height = width / 2;
		
		if(s != null) s.resize(width, height);
		
		game.setScreen(s);
	}
}
