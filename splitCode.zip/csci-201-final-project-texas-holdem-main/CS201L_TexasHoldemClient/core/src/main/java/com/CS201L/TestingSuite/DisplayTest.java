package com.CS201L.TestingSuite;

// Java library references
import java.util.Scanner;

import com.CS201L.TexasHoldemClient.BaseScreen;
import com.CS201L.TexasHoldemClient.BettingHUD;
import com.CS201L.TexasHoldemClient.ButtonElement;
import com.CS201L.TexasHoldemClient.Chip;
import com.CS201L.TexasHoldemClient.ChipDisplay;
import com.CS201L.TexasHoldemClient.GameAssets;
import com.CS201L.TexasHoldemClient.GameElement;
import com.CS201L.TexasHoldemClient.PokerCommunityCardDisplay;
import com.CS201L.TexasHoldemClient.PokerPlayerCardDisplay;
import com.badlogic.gdx.graphics.Color;
// LibGDX library references
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.viewport.Viewport;

/**
 * This class is used for testing the display of game elements so that other client
 * requirements can be ignored. Instead of running a server/client, it simulates
 * server commands through the console
 *
 * @author Nikolas Nguyen
 */
public class DisplayTest extends BaseScreen {
	// Display variables for testing
	public PokerCommunityCardDisplay cardDisplay;
	public PokerPlayerCardDisplay userDisplay;
	public PokerPlayerCardDisplay opponentDisplay;
	public ChipDisplay chipDisplay;
	public ChipDisplay pot;
	ButtonElement button;
	
	BettingHUD hud;
	
	public DisplayTest(Viewport viewport) { super(viewport); }
	
	@Override
	public void initialize() {
		System.out.println("Main Stage: " + mainStage);
		
		new GameElement(0, 0, mainStage).loadTexture("felt_poker.jpg");//"debug/debug_backdrop.jpg");
		
		cardDisplay = new PokerCommunityCardDisplay(1124, 700, mainStage);
		
		userDisplay = new PokerPlayerCardDisplay(300, 90, mainStage);
		
		opponentDisplay = new PokerPlayerCardDisplay(900, -30, mainStage);
		opponentDisplay.setRotation(30);
		
		hud = new BettingHUD(0, 0, uiStage);
		hud.toFront();
		
		/*
		 * pot = new ChipDisplay(1024, 512, mainStage); pot.divideToStacks(1262);
		 * 
		 * chipDisplay = new ChipDisplay(512, 512, mainStage);
		 * chipDisplay.divideToStacks(1262);
		 */
		
		//Card cardToFlip = new Card(1024, 512, mainStage, -1); cardToFlip.load();
		button = new ButtonElement(512, 256, uiStage, 
			() -> {
				System.out.println("Button!!!");
				if(cardDisplay.cards.size() == 0) {
					cardDisplay.dealBurn();
					cardDisplay.dealFlop(0,  14,  28);
				}
				else if(cardDisplay.cards.size() == 3) {
					cardDisplay.dealBurn();
					cardDisplay.dealTurn(42);
				}
				else if(cardDisplay.cards.size() == 4) {
					cardDisplay.dealBurn();
					cardDisplay.dealRiver(4);
				}
				//pot.transfer(50, chipDisplay);
				//cardToFlip.setCardValue(23);
				//cardToFlip.load();
			},
			() -> {
				System.out.println("Release!!!");
			});
		button.createTextLabel("Test Card Display", Color.BLACK);
	}
	
	/** Runs the test by calling the different functions */
	public void run() {
		// Use the console to simulate a server
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		
		int amount = 1262;
		System.out.println("Adding " + amount + " chips to your wallet...");
		chipDisplay.divideToStacks(amount);
		
		System.out.println("Chip List: " + GameAssets.getList(mainStage, Chip.class));
		System.out.println("Actor List: " + GameAssets.getList(mainStage, Actor.class));
		
		new Thread(() -> {
			System.out.println("Starting display run");
			String msg_server = "";
			while(!msg_server.equals("quit")) {		// Only read until the "quit" command
				msg_server = scanner.nextLine();	// Read the next line
				System.out.println("Received server message: " + msg_server);
			}
		});//.start();
		
		System.out.println("Dealing the flop...");
		cardDisplay.dealFlop(-1, 0, 14);	// Deal the flop
		
		// Pause for 3 seconds and then deal the turn
		try { Thread.sleep(3000); }
		catch (InterruptedException e) { e.printStackTrace(); }
		System.out.println("Dealing the turn...");
		cardDisplay.dealTurn(28);
		
		// Pause for 3 seconds and then deal the river
		try { Thread.sleep(3000); }
		catch (InterruptedException e) { e.printStackTrace(); }
		System.out.println("Dealing the river...");

		cardDisplay.dealRiver(42);
	}
	
	@Override
	public void resize(int width, int height) {
		cardDisplay.setPosition(width / 2.0f, height / 2.0f);
	}
	
	@Override
	public void update(float dt) {
		if(cardDisplay != null) cardDisplay.update();
		if(userDisplay != null) userDisplay.update();
		if(opponentDisplay != null) opponentDisplay.update();
		if(chipDisplay != null) chipDisplay.update();
		if(pot != null) pot.update();
		if(hud != null) hud.update();
	}
}
