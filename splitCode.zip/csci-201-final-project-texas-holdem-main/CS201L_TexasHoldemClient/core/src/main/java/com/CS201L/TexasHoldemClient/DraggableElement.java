package com.CS201L.TexasHoldemClient;

// LibGDX library references
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;

/**
 * Adds a drag-and-drop functionality to the {@link GameElement}
 * 
 * <p><strike>TODO: Implement a disable method for drag-and-drop</strike>
 * <p>TODO: Create a drag-and-drop placement and attractor class and methods
 * <p>TODO: Create a child class for chips
 *
 * @author Nikolas Nguyen
 */
public class DraggableElement extends GameElement {
	private DraggableElement self;	// A reference to itself for input listening
	
	private boolean bDraggable;	// Indicates whether this element can be moved
	private float grabOffsetX;	// The x distance the cursor has dragged
	private float grabOffsetY;	// The y distance the cursor has dragged
	
	/**
	 * Create the element with default drag-and-drop allowed and add an input
	 * listener to the application for the controls affecting this element
	 * 
	 * @param x - the x-coordinate of the element
	 * @param y - the y-coordinate of the element
	 * @param s - the stage which updates and renders this element
	 */
	public DraggableElement(float x, float y, Stage s) {
		super(x, y, s);
		bDraggable = true;
		self = this;
		
		// Add the input listener for the touch click and drag released on up
		addListener(new InputListener() {
			public boolean touchDown(InputEvent event, float eventOffsetX, 
					float eventOffsetY, int pointer, int button) {
				if(!self.bDraggable) return false;
				self.grabOffsetX = eventOffsetX;	// Save the x offset of the mouse
				self.grabOffsetY = eventOffsetY;	// Save the y offset of the mouse
				
				self.toFront();			// Bring the element to the front of display
				
				self.onDragStart();		// Run the drag function
				
				// Return true so the listener knows that we're tracking the mouse
				return true;
			}
			public void touchDragged(InputEvent event, float eventOffsetX, 
					float eventOffsetY, int pointer) {
				// The change in x and y is the difference in the offset
				float deltaX = eventOffsetX - self.grabOffsetX;
				float deltaY = eventOffsetY - self.grabOffsetY;
				
				self.moveBy(deltaX, deltaY);	// Move the element
			}
			public void touchUp(InputEvent event, float offsetX, float offsetY,
					int pointer, int button) {
				self.onDrop();	// Run the function for dropping the element
			}
		});
	}
	
	/**
	 * Called whenever the dragging of the element has started, i.e. when the cursor
	 * is over the element and a mouse button is held down
	 */
	public void onDragStart() {	}
	
	/** 
	 * Called whenever the element has been dropped, i.e. when a cursor dragging the
	 * element has lifted the button 
	 */
	public void onDrop() { }
	
	// Get-Set Functions
	public boolean isDraggable() { return bDraggable; } 
	
	public void setDraggability(boolean draggable) { bDraggable = draggable; }
}
