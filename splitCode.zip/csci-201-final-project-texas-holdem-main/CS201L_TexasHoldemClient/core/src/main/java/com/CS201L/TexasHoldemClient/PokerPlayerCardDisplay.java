package com.CS201L.TexasHoldemClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;
import com.badlogic.gdx.utils.Align;

/**
 * This class is used for arranging the cards of some player's hand for poker. It
 * stores the {@link GameElement} objects representing the cards and sets their 
 * position and rotation on the board.
 * 
 * <p>TODO: Correct the position and rotation of the display and the cards so that
 * they are oriented based on the center rather than the bottom left corner for
 * easier layout.
 * <p>TODO: Create resizing functionality for minimally overlapping the cards.
 * <p><strike>TODO: Make this a child of {@link com.badlogic.gdx.scenes.scene2d.Group}, so
 * that it can parent the player cards for easier management of position, rotation,
 * scale, etc.</strike>
 * <p>TODO: Render the players chips as draggable for betting
 * <p>TODO: Add a drag-and-drop element attractor for the player's bet (call/raise)
 * <p>TODO: Create animations for being dealt cards
 *
 * @author Nikolas Nguyen
 */
public class PokerPlayerCardDisplay extends GameElement implements ThreadSafeAsset {
	public List<Card> cards;
	
	protected boolean bLoaded;
	protected boolean bOpponent;
	
	public PokerPlayerCardDisplay(float x, float y, Stage s) { this(x, y, s, 0.0f); }
	
	/**
	 * This is the basic constructor for setting up the display in screen space and
	 * the stage which it and all its cards will belong to.
	 * 
	 * @param x- the x-coordinate for the display
	 * @param y - the y-coordinate of the display
	 * @param s - the stage that holds the card assets
	 * @param rotation - the rotation of the display
	 */
	public PokerPlayerCardDisplay(float x, float y, Stage s, float rotation) {
		super(x, y, s);
		
		cards = Collections.synchronizedList(new ArrayList<Card>(2));
		setRotation(rotation);
		setSize(512, 340);
		setOrigin(Align.center);
		
		bLoaded = false;
	}
	
	/** @deprecated Adds a hidden card to this player's display (for opponents) */
	public void addPrivateCard() {
		if(cards.size() < 2) {
			Card card = new Card((256 * cards.size()), 0, getStage(), -1);
			cards.add(card);
			card.bReturnCard = true;
			addActor(card);
		}
	}
	
	public void addPrivateCard(Card topCard) {
		if(cards.size() < 2) {
			cards.add(topCard);
			
			final float x = 256 * cards.size();
			final float y = 0;
			Vector2 screenCoords = localToActorCoordinates(topCard, new Vector2(x, y));
			topCard.addAction(Actions.parallel(
					Actions.moveBy(screenCoords.x, screenCoords.y, 0.5f),
					Actions.scaleTo(getScaleX(), getScaleY(), 0.5f),
					Actions.rotateTo(getRotation(), 0.5f)));
			topCard.bReturnCard = bOpponent;
			
			RunnableAction parentAction = new RunnableAction();
			parentAction.setRunnable(() -> { 
				addActor(topCard);
				
				topCard.setPosition(x, y);
				topCard.setScale(1.0f);
				topCard.setRotation(0);
				
				topCard.toFront();
			});
			topCard.addAction(Actions.after(parentAction));
		}
	}
	
	/** @deprecated Adds a visible card to this player's display (for user) */
	public void addPublicCard(int cardValue) {
		if(cards.size() < 2) {
			Card card = new Card((256 * cards.size()), 0, getStage(), cardValue);
			card.bReturnCard = bOpponent;
			cards.add(card);
			addActor(card);
		}
	}
	
	public void addPublicCard(Card topCard, int cardValue) {
		if(cards.size() < 2) {
			cards.add(topCard);
			
			final float x = 256 * cards.size();
			final float y = 0;
			Vector2 screenCoords = localToActorCoordinates(topCard, new Vector2(x, y));
			topCard.addAction(Actions.parallel(
					Actions.moveBy(screenCoords.x, screenCoords.y, 0.5f),
					Actions.scaleTo(getScaleX(), getScaleY(), 0.5f),
					Actions.rotateTo(getRotation(), 0.5f)));
			topCard.bReturnCard = bOpponent;
			
			RunnableAction flipAction = new RunnableAction();
			flipAction.setRunnable(() -> { 
				addActor(topCard);
				
				topCard.setCardValue(cardValue);
				topCard.setPosition(x, y);
				topCard.setScale(1.0f);
				topCard.setRotation(0);
				
				topCard.toFront();
			});
			topCard.addAction(Actions.after(flipAction));
		}
		else topCard.remove();
	}
	
	public void fold() {
		TextLabel label = new TextLabel(0, 0, getStage(), "FOLD");
		label.setPosition(512, getOriginY(), Align.center);
		label.setColor(Color.FIREBRICK);
		for(Card c : cards) {
			c.setColor(Color.GRAY);
			c.setDraggability(false);
		}
		addActor(label);
	}
	
	/** Reveals the two cards in this player's hand (for opponents at the end) */
	public void reveal(int cardValue1, int cardValue2) {
		if(cards.size() == 2) {
			cards.get(0).setCardValue(cardValue1);
			cards.get(1).setCardValue(cardValue2);
		}
	}
	
	/** Updates each of the cards to match the texture if not loaded */
	public void update() { if(!isLoaded()) load(); }

	@Override
	public void load() {
		bLoaded = true;
		for(Card c : cards) if(!c.isLoaded()) c.load();
	}

	@Override
	public boolean isLoaded() { 
		boolean result = bLoaded;
		for(Card c : cards) result &= c.isLoaded();
		return result;
	}

	@Override
	public void setLoaded(boolean loaded) { bLoaded = loaded; }

	public void setOpponentMode(boolean oppMode) { 
		bOpponent = oppMode;
		if(oppMode) {
			for(Card c : cards) c.bReturnCard = true;
		}
	}
}
