package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.List;
// LibGDX library references
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;

/**
 * Provides a basic way of creating chip assets for rendering and UI. Can be dragged
 * by the user as a default. The values allowed by the chip are limited by the enum 
 * {@link CHIP_VALUE} to the most common chip values and for easy retrieval of the
 * texture file.
 * 
 * <p>TODO: Set up the {@link ChipDisplay} class for rendering stacks of chips for 
 * the player 
 *
 * @author Nikolas Nguyen
 */
public class Chip extends DraggableElement {
	public final CHIP_VALUE chipValue;
	
	public float lastX;
	public float lastY;
	
	public boolean bLoaded;
	
	public Chip(float x, float y, Stage s) { this(x, y, s, CHIP_VALUE.ONE); }
	
	/**
	 * Creates a chip as a draggable element at the position (x, y) in the given
	 * stage and with a value from the {@link CHIP_VALUE} enum. This will
	 * automatically load the correct texture for the value.
	 * 
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 * @param value - the enum value of the chip
	 * 
	 * @see {@link CHIP_VALUE}{@code .chip_from_int(int value)}
	 */
	public Chip(float x, float y, Stage s, CHIP_VALUE value) {
		super(x, y, s);
		chipValue = value;
	}
	
	public void load() {
		System.out.println("Loading texture (" + chipValue.getTexturePath() + ") for chip at ("
				+ getX() + ", " + getY() + ")");
		loadTexture(chipValue.getTexturePath());
		System.out.println("\tTexture " + texture);
		bLoaded = true;
		toFront();
		setVisible(true);
	}
	
	@Override
	public void onDragStart() { lastX = getX(); lastY = getY(); }
	
	@Override
	public void onDrop() { 
		List<ChipDisplay> list = GameAssets.getList(getStage(), ChipDisplay.class);
		for(ChipDisplay a : list) {
			if(this.intersects(a) && a != this.getParent().getParent()) {
				a.transfer(this);
				return;
			}
		}
		
		addAction(Actions.moveTo(lastX, lastY, 0.0625f));
	}
	
	public void update() { if(!isLoaded()) load(); }
	
	// Get-Set Functions
	public int getValue() { return chipValue.value(); }
	
	public boolean isLoaded() { return bLoaded; }
}