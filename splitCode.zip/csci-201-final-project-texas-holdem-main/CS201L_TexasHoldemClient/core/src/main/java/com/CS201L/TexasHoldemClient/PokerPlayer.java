package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.ArrayList;
import java.util.List;

/**
 * This class is responsible for storing the card values of each player on the table
 * as well as if the private card has been dealt to them.
 * 
 * @author Nikolas Nguyen
 */
public class PokerPlayer {
	public List<Integer> cards;	// Stores the values of the players hand (-1 to hide)
	
	/**
	 * The basic constructor which sets the card storage which is set to be 
	 * thread-safe using synchronized Collections. This allows the client listening
	 * to access and modify the list of cards to update the GUI 
	 */
	public PokerPlayer() { 
		cards = java.util.Collections.synchronizedList(new ArrayList<Integer>(2));
	}
	
	/**
	 * @param card - the Integer card value to add to the hand's public cards
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 */
	public void dealCard(Integer card) { if(cards.size() < 2) cards.add(card); }
	
	/** Tells this player that a hidden card has been dealt for opponents' display */
	public void dealPrivateCard() { if(cards.size() < 2) cards.add(-1); }
	
	/**
	 * Called when the server reveals an opponent's cards to the user at the end of a
	 * showdown.
	 * 
	 * @param cardValue1 - the first card of the opponent's hand
	 * @param cardValue2 - the second card of the opponent's hand
	 */
	public void revealPrivateCards(int cardValue1, int cardValue2) {
		if(cards.size() == 2) {			// Make sure the opponent is already dealt
			cards.set(0, cardValue1);
			cards.set(1, cardValue2);
		}
	}
}