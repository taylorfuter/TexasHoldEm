package com.CS201L.TexasHoldemClient;

//LibGDX library references
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.Viewport;

/**
 * Handles the user login assets and processing the login request.
 * 
 * <p>TODO: Connect to the login database
 * <p>TODO: Create some way to store relevant user information like betting wallet
 * and account for entering a poker game.
 * <p>TODO: Maybe separate the login graphics asset and functionality to a separate
 * class so that the login data can be done with different applications or from
 * different screens
 * 
 * @author Nikolas Nguyen
 */
public class LoginScreen extends BaseScreen {
	protected BaseScreen prevScreen;		// The previous screen for going back
	
	protected PokerClient client;
	
	protected InputListener enterListener;
	
	protected TextEntry usernameEntry;
	protected TextEntry passwordEntry;
	
	protected ButtonElement loginButton;	// For running a login request
	protected ButtonElement cancelButton;	// For bringing focus back to last screen
	
	protected boolean bLogin;
	
	/**
	 * @param prevScreen - the screen that is entering the login so that the user can
	 * go back to where they started
	 */
	public LoginScreen(Viewport viewport, BaseScreen prevScreen) {
		super(viewport);
		this.prevScreen = prevScreen; 
	}
	
	public void close() { 
		client.close();
		BaseGame.setActiveScreen(new MenuScreen(viewport));
	}
	
	@Override
	public void initialize() {
		// Create the background image
		new GameElement(0, 0, mainStage).loadTexture("Login.jpg");
		new Thread(() -> {
			try {
				client = new PokerClient("localhost", 6789, this);
				client.start();
			}
			catch (Exception e) {
				createErrorMessageBox("Could not connect to the\nlogin service");;
			}
		}).start();
		
		TextField.TextFieldStyle style = new TextField.TextFieldStyle();
		style.background = GameAssets.loadNinePatch("textfield_9patch.png");
		style.font = GameAssets.defaultFont;
		style.fontColor = Color.BLACK;
		
		// Initialize a field for the user to enter their username
		usernameEntry = new TextEntry(0, 0, uiStage);
		usernameEntry.getTextField().setMaxLength(15);
		usernameEntry.getTextField().setFocusTraversal(true);
		usernameEntry.setWidth(750);
		//usernameEntry.getTextField().setPosition(0, 0, Align.center);
		usernameEntry.setScale(0.75f);
		
		// Initialize a field for the user to enter their password
		passwordEntry = new TextEntry(0, 0, uiStage);
		passwordEntry.getTextField().setPasswordMode(true);	// Make sure it's hidden
		passwordEntry.getTextField().setPasswordCharacter('�');
		passwordEntry.getTextField().setMaxLength(20);
		passwordEntry.setWidth(750);
		passwordEntry.getTextField().setPosition(0, 0, Align.bottomLeft);
		passwordEntry.setScale(0.75f);
		
		TextLabel usernameLabel = new TextLabel(0, 0, uiStage, "Username: ", Color.WHITE);
		usernameLabel.setScale(0.75f);
		
		// The label that will also act as a parent for the visibility button
		TextLabel passwordLabel = new TextLabel(0, 0, uiStage, "Password: ", Color.WHITE);
		passwordLabel.setScale(0.75f);
		
		// Initialize a button which toggles password visibility when held
		ButtonElement passwordVisibilityButton = new ButtonElement(0, 0, uiStage);
		GameElement visibilityIcon = new GameElement(0, 0, uiStage);
		visibilityIcon.loadTexture("visibility.png");
		passwordVisibilityButton.setIcon(visibilityIcon);
		passwordVisibilityButton.setActionPressed(() -> { 
			passwordEntry.getTextField().setPasswordMode(false);	// Make the password visible
		});
		passwordVisibilityButton.setActionReleased(() -> {
			passwordEntry.getTextField().setPasswordMode(true);	// Make it invisible again
		});
		passwordEntry.addActor(passwordVisibilityButton);
		passwordVisibilityButton.setPosition(
				passwordEntry.getWidth() - (passwordVisibilityButton.getWidth() / 2) - 16,
				passwordEntry.getOriginY(), Align.center);
		passwordLabel.toFront();	// Bring it to the front so it can be pressed
		
		// Prepare the login button which submits the login request when pressed
		loginButton = new ButtonElement(0, 0, uiStage);
		//loginButton.setPosition(0, 0, Align.center);
		loginButton.setText("Login");
		loginButton.setActionPressed(() -> { sendLoginRequest(); });
		
		enterListener = new InputListener() {
			public boolean keyDown(InputEvent event, int keycode) {
				if(keycode == Keys.ENTER) sendLoginRequest();
				return true;	// We've handled the event
			}
		};
		uiStage.addListener(enterListener);
		
		// Prepare the cancel button which will bring the user back when pressed
		cancelButton = new ButtonElement(0, 0, uiStage);
		cancelButton.setText("Cancel");;
		cancelButton.setActionPressed(() -> { BaseGame.setActiveScreen(prevScreen); });
		
		TextLabel signupLabel = new TextLabel(0, 0, uiStage, "Not registered? ");
		
		ButtonElement signupButton = new ButtonElement(0, 0, uiStage);
		signupButton.setText("Sign Up");
		signupButton.setActionPressed(() -> { 
			passwordEntry.setText("");
			BaseGame.setActiveScreen(new SignupScreen(viewport, client));
		});
		signupButton.addActor(signupLabel);
		signupLabel.setPosition(-signupLabel.getWidth(), 0);
		signupButton.setScale(0.5f);
		
		// Create a table for organizing the layout of the login information
		Table loginTable = new Table();
		loginTable.setFillParent(true);
		uiStage.addActor(loginTable);
		
		// Create the table row for username info
		loginTable.add(usernameLabel).right();
		loginTable.add(usernameEntry);
		
		// Create the table row for the password info
		loginTable.row();
		loginTable.add(passwordLabel).right();
		loginTable.add(passwordEntry);
		
		// Create the row for the buttons
		loginTable.row().padTop(12);
		loginTable.add(loginButton).right().prefWidth(loginButton.getWidth());
		loginTable.add(cancelButton).center().prefWidth(cancelButton.getWidth());
		
		loginTable.row().colspan(2).padTop(50);
		loginTable.add(signupButton).center();
	}
	
	@Override
	public void update(float dt) {
		if(bLogin && !client.hasPokerScreen()) {
			PokerScreen screen = new PokerScreen(viewport,
					new MenuScreen(viewport), client);
			client.setPokerScreen(screen);
			BaseGame.setActiveScreen(screen);
			bLogin = false;
		}
	}
	
	@Override
	public void createErrorMessageBox(String message) {
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox errMsg = new MessageBox(0, 0, uiStage, "Error", message);
		errMsg.setPosition(x, y, Align.center);
		errMsg.setCancelAction(() -> { 
			BaseGame.setActiveScreen(new MenuScreen(viewport));
		});
		errMsg.setOKAction(() -> {
			BaseGame.setActiveScreen(new MenuScreen(viewport));
		});
		
		loginButton.clearActionPressed();
		cancelButton.clearActionPressed();
		
		uiStage.removeListener(enterListener);
	}
	
	public void createSignupMessageBox(String message) {
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox msgBox = new MessageBox(0, 0, uiStage, "Signup", message);
		msgBox.setPosition(x, y, Align.center);
		ButtonElement.ButtonAction enableAction = new ButtonElement.ButtonAction() {
			public void activate() {
				loginButton.setActionPressed(() -> { sendLoginRequest(); });
				cancelButton.setActionPressed(() -> { 
					BaseGame.setActiveScreen(prevScreen);
				});
			}
		};
		msgBox.setOKAction(enableAction);
		msgBox.setCancelAction(enableAction);
		
		loginButton.clearActionPressed();
		cancelButton.clearActionPressed();
		
		uiStage.removeListener(enterListener);
	}
	
	/**
	 * Perform the login request from the user's input. 
	 * 
	 * <p>TODO: Add the hashing function somewhere
	 * <p>TODO: Connect to the login database
	 * <p>TODO: 
	 * */
	public void sendLoginRequest() {
		String username = usernameEntry.getText();
		String password = passwordEntry.getText();
		
		if(client == null || !client.isConnected()) 
			createErrorMessageBox("No login service connection");
		
		if(username.equals("")) usernameEntry.flagError("A username is required");
		else if(password.equals("")) passwordEntry.flagError("A password is required");
		else client.echoServer("login " + username + " " + password);
	}
	
	public void setLoginSuccess() { bLogin = true; }
}
