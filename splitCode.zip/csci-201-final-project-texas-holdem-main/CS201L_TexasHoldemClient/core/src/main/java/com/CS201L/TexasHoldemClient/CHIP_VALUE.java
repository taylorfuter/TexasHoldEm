package com.CS201L.TexasHoldemClient;

/**
 * The chip values stored as an enum to keep the chip options discrete and help
 * to translate between human readable and integer value. Provides a method for 
 * the string path to the texture file name (.png) for rendering the chip
 *
 * @author Nikolas Nguyen
 */
public enum CHIP_VALUE { 
	ONE(1), FIVE(5), TWENTY_FIVE(25),
	ONE_HUNDRED(100), FIVE_HUNDRED(500);
	
	private int value; 			// The dollar value of the chip
	private String texturePath;	// The path to the texture file for rendering
	
	/**
	 * Sets the chip enum's dollar value and creates the path String for easy
	 * translation to the texture file.
	 * 
	 * @param value - the corresponding integer dollar value of the chip
	 */
	private CHIP_VALUE(int value) {
		this.value = value;
		texturePath = "chips/chip_" + value + ".png";
	}
	
	/**
	 * Translates the given integer (dollar) value of the chip to the
	 * corresponding enum value. If no direct match is found, 
	 * {@link CHIP_VALUE.ONE} is assumed
	 * 
	 * @param value - integer value of the chip
	 * @return The {@link CHIP_VALUE} equivalent to the given value
	 */
	public CHIP_VALUE chipFromInt(int value) {
		for(CHIP_VALUE c : CHIP_VALUE.values()) { if(value == c.value) return c; }
		return ONE;
	}
	
	/** @return The path to the texture file for rendering */
	public String getTexturePath() { return texturePath; }
	
	/** @return The dollar value of the chip */
	public int value() { return value; }
}