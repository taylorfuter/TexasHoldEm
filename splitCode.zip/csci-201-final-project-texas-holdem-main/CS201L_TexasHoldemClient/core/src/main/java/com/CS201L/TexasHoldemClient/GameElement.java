package com.CS201L.TexasHoldemClient;

// LibGDX library references
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.utils.TransformDrawable;

/** 
 * Extends the actor and group functionality wrapping all the functions needed for
 * rendering and storing the state of assets in the game. Thsi version of the game
 * element is meant to be thread-safe for OpenGL. Namely, that it is capable of doing
 * it's texture loading in the thread that has an OpenGL device attached to it which
 * is usually the main thread or wherever the stage is located.
 *
 * <p>TODO: Correct the positioning of the Drawable texture (hopefully not through a
 * separate class) since the current positioning has it in the right visual location,
 * but the collision bounds are offset by half the width. This is because the libGDX
 * positions are measured from the bottom left corner, but parenting the other game
 * elements has them on the center.
 * <p>TODO: Fix the implementation to match the needs of the game server rather than
 * the example from which this code was drawn.
 * <p>TODO: Separate the OpenGL thread safety functions to an interface to separate
 * it from other client side graphics resources. 
 */
public class GameElement extends Group {
	// Animation members
	protected TransformDrawable texture;
	
	protected float boundingRadius;
	protected Rectangle boundingBox;
	
	// Constructor
	/**
	 * @param x - the x-coordinate of the element
	 * @param y - the y-coordinate of the element
	 * @param s - the stage which updates and renders this element
	 */
	public GameElement(float x, float y, Stage s) {
		super();
		setPosition(x, y);
		s.addActor(this);
		
		texture = null;
	}

	// Game engine functions
	
	@Override
	public void draw(Batch batch, float parentAlpha) {
		Color c = getColor();
		batch.setColor(c.r, c.g, c.b, c.a);
		
		if(texture != null && isVisible()) {
			texture.draw(batch, getX(), getY(), getOriginX(), getOriginY(),
					getWidth(), getHeight(), getScaleX(), getScaleY(),
					getRotation());
		}
		
		super.draw(batch, parentAlpha);
	}
	
	// State update functions for overriding in child classes
	
	/**
	 * Meant to be called whenever the screen/stage that holds this element has been
	 * paused. All the time-based resources should be updated or paused to reflect
	 * the game state.
	 */
	public void onPause() {
		return;
	}
	
	/**
	 * Meant to be called whenever the screen/stage that holds this element has
	 * resumed activity. All the time-based resources should be updated or resumed to
	 * reflect the game state
	 */
	public void onResume() {
		return;
	}
	
	/**
	 * Meant to detect collision with other elements
	 * 
	 * @param other - the other {@link GameElement} to check collisions with
	 * @return Indicates whether the two are intersecting.
	 * 
	 * */
	public boolean intersects(GameElement other) {
		return this.getBoundingBox().overlaps(other.getBoundingBox());
	}
	
	// Resource loading functions
	
	/**
	 * Loads the drawable texture using the asset utility class and update the
	 * elements sizing to match the object.
	 * 
	 * @param filename - the file path to load the texture from
	 *  */
	public void loadTexture(String filename) {
		texture = GameAssets.loadTexture(filename);
		
		float width = texture.getMinWidth();
		float height = texture.getMinHeight();
		setSize(width, height);
		setOrigin(-width / 2, -height / 2);
	}

	// Get-Set Functions
	
	public Rectangle getBoundingBox() {
		Vector2 pos = localToScreenCoordinates(new Vector2(0, 0));
		return boundingBox.setPosition(pos);
	}
	
	@Override
	public void setSize(float width, float height) {
		super.setSize(width, height);
		boundingBox = new Rectangle(getX(), getY(), width, height);
	}
	
	public void setTexture(TransformDrawable texture) { 
		this.texture = texture;
		setSize(texture.getMinWidth(), texture.getMinHeight());
	}
}
