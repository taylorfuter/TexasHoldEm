package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.Align;

/**
 * Originally meant to add easier functionality to text fields; however, it turned
 * out that its much easier to keep TextFields as non-{@link GameElement} actors in
 * the scene and have other, related GameElements take care of the event handling
 * e.g. a {@link ButtonElement} object
 * 
 * <p>TODO: Correct the lack of functionality to reestablish the relevance of this
 * class (it would be easier to encapsulate the font functions and positioning if it
 * were a GameElement, especially with regards to a default font.
 * <p>TODO: Create some sort of texture loading so the text field isn't floating in
 * empty space anymore
 *
 * @author Nikolas Nguyen
 */
public class TextEntry extends GameElement {	
	public TextField field;
	
	protected TextField.TextFieldStyle normalStyle;
	protected TextField.TextFieldStyle errorStyle;
	
	protected boolean bError;
	protected String errMsg = "";
	protected TextLabel errLabel = null;
	
	// Constructors
	public TextEntry(float x, float y, Stage s) {
		this(x, y, s, GameAssets.defaultFieldStyle, GameAssets.defaultErrorFieldStyle);
	}
	
	public TextEntry(float x, float y, Stage s, BitmapFont font, Color color) {
		this(x, y, s, new TextField.TextFieldStyle(font, color, null, null, null));
	}
	
	public TextEntry(float x, float y, Stage s, TextField.TextFieldStyle style) {
		this(x, y, s, style, GameAssets.defaultErrorFieldStyle);
	}
	
	public TextEntry(float x, float y, Stage s, TextField.TextFieldStyle style,
			TextField.TextFieldStyle errorStyle) {
		super(x, y, s);
		
		normalStyle = style;
		this.errorStyle = errorStyle;
		
		field = new TextField(null, normalStyle);
		addActor(field);
		field.setPosition(0, 0);
		
		setSize(field.getWidth(), field.getHeight());
		setOrigin(Align.center);
		
		bError = false;
	}
	
	public void flagError(String msg) {
		errMsg = msg;
		if(errLabel != null) errLabel.setText(errMsg);
		setErrorMode(true);
	}
	
	// Get-Set Functions
	public boolean isErrorMode() { return bError; }
	
	public String getText() { return field.getText(); }

	public TextField getTextField() { return field; }
	
	public void setColor(Color color) {
		field.setStyle(new TextField.TextFieldStyle(field.getStyle().font, color, null, null, null));
	}
	
	public void setErrorMode(boolean error) { if(error ^ bError) toggleError();	}
	
	public void setErrorStyle(TextField.TextFieldStyle style) {
		errorStyle = style;
		if(bError) field.setStyle(errorStyle);
	}
	
	public void setFont(BitmapFont font, Color color) {
		normalStyle = new TextField.TextFieldStyle(normalStyle);
		normalStyle.font = font;
		normalStyle.fontColor = color;
		
		errorStyle = new TextField.TextFieldStyle(errorStyle);
		errorStyle.font = font;
		errorStyle.fontColor = color;
		
		if(bError) field.setStyle(errorStyle);
		else field.setStyle(normalStyle);
	}
	
	public void setStyle(TextField.TextFieldStyle style) {
		normalStyle = style;
		if(!bError) field.setStyle(style);
	}
	
	public void setText(String text) { field.setText(text); }
	
	public void setWidth(int width) {
		super.setWidth(width);
		field.setWidth(width);
		setOrigin(Align.center);
	}
	
	public void toggleError() {
		if(bError) {
			bError = false; 
			field.setStyle(normalStyle);
			if(errLabel != null)
				errLabel.setVisible(false);
		}
		else { 
			bError = true;
			field.setStyle(errorStyle);
			if(errLabel == null) {
				errLabel = new TextLabel(0, 0, getStage(), errMsg);
				errLabel.setColor(Color.RED);
				errLabel.setScale(0.4f);
				
				addActor(errLabel);
				errLabel.setPosition(0, getHeight() + 8);
				errLabel.toFront();
			}
			errLabel.setVisible(true);
		}
	}
}
