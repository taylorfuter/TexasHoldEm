package com.CS201L.TexasHoldemClient;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.NinePatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.utils.TransformDrawable;
import com.badlogic.gdx.utils.Array;

public class GameAssets {
	/** Used to prevent instantation of this utility class */
	private GameAssets() { }

	// Game Defaults - Textures
	/** The globally shared texture default for when textures cannot be loaded */
	public static Texture defaultTexture = loadDefaultTexture();
	
	// Game Defaults - Fonts
	
	/** 
	 * The globally shared font default settings. If it's not overriden, the default
	 * is libGDX's 15pt Arial font
	 * 
	 * <p>TODO: Move to a utility class 
	 * */
	public static BitmapFont defaultFont = new BitmapFont();
	/** 
	 * The globally shared font default style for text labels. If it's not overriden
	 * the default is libGDX's 15pt Arial font in black.
	 * 
	 * <p>TODO: Move to a utility class
	 * */
	public static LabelStyle defaultLabelStyle = new LabelStyle(defaultFont, Color.WHITE);
	
	// Game Defaults - UI
	
	public static ButtonStyle defaultButtonStyle = loadDefaultButtonStyle();
	
	public static TextField.TextFieldStyle defaultErrorFieldStyle = loadDefaultErrorFieldStyle();

	public static TextField.TextFieldStyle defaultFieldStyle = loadDefaultFieldStyle();
	
	public static NinePatchDrawable defaultDialogBoxStyle = loadDefaultDialogBoxStyle();
	
	/**
	 * Loads an animation from the given file as a sequence of tiles in the image
	 * 
	 * <p>TODO: Separate these into a utility class
	 * 
	 * @param filename - the path to the image file
	 * @param rows - the number of rows of frame tiles
	 * @param columns - the number of columns of frame tiles
	 * @param frameDuration - the length of time for each frame
	 * @param loop - indicates whether the animation should be looped at the end
	 * @return The animation as a series of 
	 * {@link com.badlogic.gdx.graphics.g2d.TextureRegion} objects
	 */
	public static Animation<TextureRegion> loadAnimationFromImageAtlas(String filename, int rows,
			int columns, float frameDuration, boolean loop) {
		Texture tex = new Texture(Gdx.files.internal(filename));
		tex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
		int frameWidth = tex.getWidth() / columns;
		int frameHeight = tex.getHeight() / rows;
		
		TextureRegion[][] temp = TextureRegion.split(tex, frameWidth, frameHeight);
		Array<TextureRegion> textureArray = new Array<TextureRegion>();
		for(int i = 0; i < frameHeight; i++) 
			for(int j = 0; j < frameWidth; j++)
				textureArray.add(temp[i][j]);
		
		Animation<TextureRegion> anim = new Animation<TextureRegion>(frameDuration,
				textureArray);
		if(loop) anim.setPlayMode(Animation.PlayMode.LOOP);
		else anim.setPlayMode(Animation.PlayMode.NORMAL);
		
		return anim;
	}
	
	public static Animation<TextureRegion> loadAnimationFromImageSequence(String[] fileNames, 
			float frameDuration, boolean loop) {
		int fileCount = fileNames.length;
		Array<TextureRegion> textureArray = new Array<TextureRegion>();
		
		for(int i = 0; i < fileCount; i++) {
			String filename = fileNames[i];
			Texture tex = new Texture(Gdx.files.internal(filename));
			tex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
			textureArray.add(new TextureRegion(tex));
		}
		
		Animation<TextureRegion> anim = new Animation<TextureRegion>(frameDuration,
				textureArray);
		if(loop) anim.setPlayMode(Animation.PlayMode.LOOP);
		else anim.setPlayMode(Animation.PlayMode.NORMAL);
		
		return anim;
	}
	
	public static TextureRegionDrawable loadTexture(String filename) {
		FileHandle file = Gdx.files.local(filename);
		if(!file.exists()) return new TextureRegionDrawable(loadDefaultTexture());
		
		Texture tex = new Texture(file);
		tex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
		
		return new TextureRegionDrawable(tex);
	}
	
	public static NinePatchDrawable loadNinePatch(String filename) {
		FileHandle file = Gdx.files.local(filename);
		if(!file.exists()) return new NinePatchDrawable(loadDefaultNinePatch());
		
		Texture tex = new Texture(file);
		tex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
		int patchWidth = tex.getWidth() / 3;
		int patchHeight = tex.getHeight() / 3;
		
		NinePatch ninePatch = new NinePatch(tex,
				patchWidth, patchWidth, patchHeight, patchHeight);
		
		return new NinePatchDrawable(ninePatch);
	}
	
	/**
	 * TODO: Push this into some sort of utility class for common loading of game
	 * resources.
	 * 
	 * @param filePath - the path to the .fnt bitmap font file for loading
	 */
	public static BitmapFont loadFont(String filePath) {
		return new BitmapFont(Gdx.files.internal(filePath));
	}
	
	// Private default resource loaders
	
	private static ButtonStyle loadDefaultButtonStyle() {
		NinePatchDrawable up = new NinePatchDrawable(loadDefaultNinePatch());
		
		return new ButtonStyle(up, null, null);
	}
	
	private static TextField.TextFieldStyle loadDefaultFieldStyle() {
		Pixmap pix = new Pixmap(48, 48, Pixmap.Format.RGB888);
		
		pix.setColor(Color.BLUE);
		pix.fillRectangle(0, 0, 48, 48);
		pix.setColor(Color.WHITE);
		pix.fillRectangle(4, 4, 44, 44);
		
		NinePatchDrawable background = new NinePatchDrawable(new NinePatch(
				new Texture(pix), 16, 16, 16, 16));
		
		return new TextField.TextFieldStyle(defaultFont, 
				Color.BLACK, null, null, background);
	}
	
	private static TextField.TextFieldStyle loadDefaultErrorFieldStyle() {
		Pixmap pix = new Pixmap(48, 48, Pixmap.Format.RGB888);
		
		pix.setColor(Color.RED);
		pix.fillRectangle(0, 0, 48, 48);
		pix.setColor(Color.WHITE);
		pix.fillRectangle(4, 4, 44, 44);
		
		NinePatchDrawable background = new NinePatchDrawable(new NinePatch(
				new Texture(pix), 16, 16, 16, 16));
		
		return new TextField.TextFieldStyle(defaultFont, 
				Color.BLACK, null, null, background);
	}
	
	private static NinePatchDrawable loadDefaultDialogBoxStyle() {
		Pixmap pix = new Pixmap(48, 48, Pixmap.Format.RGB888);
		
		pix.setColor(Color.BLUE);
		pix.fillRectangle(0, 0, 48, 48);
		pix.setColor(Color.WHITE);
		pix.fillRectangle(4, 4, 40, 40);
		
		return new NinePatchDrawable(new NinePatch(
				new Texture(pix), 16, 16, 16, 16));
	}
	
	private static NinePatch loadDefaultNinePatch() {
		Pixmap pix = new Pixmap(96, 96, Pixmap.Format.RGB888);
		
		pix.setColor(Color.BLACK);
		pix.fillRectangle(0, 0, 96, 96);
		
		pix.setColor(Color.MAGENTA);
		for(int i = 0; i < 6; i++)
			for(int j = 0; j < 6; j++)
				if(((i + j) % 2) == 0) pix.fillRectangle(i * 16, j * 16, 16, 16);
		
		return new NinePatch(new Texture(pix), 32, 32, 32, 32);
	}
	
	private static Texture loadDefaultTexture() {
		Pixmap pix = new Pixmap(128, 128, Pixmap.Format.RGB888);
		
		pix.setColor(Color.BLACK);
		pix.fillRectangle(0, 0, 128, 128);
		
		pix.setColor(Color.MAGENTA);
		for(int i = 0; i < 8; i++)
			for(int j = 0; j < 8; j++)
				if(((i + j) % 2) == 0) pix.fillRectangle(i * 16, j * 16, 16, 16);
		
		return new Texture(pix);
	}
	
	//Get-Set Functions (for game defaults)
	
	public static void setGameDefaultButtonStyle(ButtonStyle style) {
		defaultButtonStyle = style;
	}
	
	public static void setGameDefaultErrorFieldStyle(TextField.TextFieldStyle style) {
		defaultErrorFieldStyle = style;
	}
	
	public static void setGameDefaultFieldStyle(TextField.TextFieldStyle style) {
		defaultFieldStyle = style;
	}
	
	/** TODO: Push this into some sort of utility class for common loading of game
	 * resources.
	 * 
	 * @param font - the bitmap font to use as the game's default
	 */
	public static void setGameDefaultFont(BitmapFont font) { 
		defaultFont = font;
		defaultLabelStyle.font = font;
	}
	
	/**
	 * TODO: Push this into some sort of utility class for common loading of game
	 * resources.
	 * 
	 * @param color - the color to use as the game's default font color
	 */
	public static void setGameDefaultFontColor(Color color) { defaultLabelStyle.fontColor = color; }
	
	public static void setGameDefaultDialogBoxStyle(NinePatchDrawable background) {
		defaultDialogBoxStyle = background;
	}
	
	/**
	 * Returns the list of GameElements in given stage that match the given class. 
	 * Used for processing specific classes of game elements
	 * @param <T>
	 * 
	 * @param stage - the stage to gather elements from
	 * @param elementClass - the class type that extends GameElement to retrieve from
	 * the stage
	 * @return The list of GameElement objects of the given class that have been 
	 * added to the stage
	 */
	public static <T extends Actor> ArrayList<T> getList(Stage stage,
			Class<T> elementClass) {
		// Initialize the list
		ArrayList<T> list = new ArrayList<T>();
		
		// Iterate over each actor in the stage list
		for(Actor a : stage.getActors()) {
			if(elementClass.isInstance(a)) {	// Check that it is the correct type
				try {
					T validActor = elementClass.cast(a);
					list.add(validActor);		// If so, add it to the list
				}			
				catch(ClassCastException e) {
					System.out.println(e.getClass() + " encountered");
				}
			}
		}
		
		return list;
	}
	
	public static class ButtonStyle {
		public TransformDrawable up;
		public TransformDrawable down;
		public TransformDrawable over;
		public TransformDrawable focused;
		public TransformDrawable checked;
		public TransformDrawable checkedOver;
		public TransformDrawable checkedFocused;
		public TransformDrawable disabled;
		
		public ButtonStyle() { }
		
		public ButtonStyle(TransformDrawable up, TransformDrawable down,
				TransformDrawable over) {
			this.up = up;
			this.down = down;
			this.over = over;
		}
	}
}
