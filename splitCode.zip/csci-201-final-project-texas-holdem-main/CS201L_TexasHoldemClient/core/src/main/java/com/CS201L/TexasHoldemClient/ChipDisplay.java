package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.TreeMap;
// LibGDX library references
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;

/**
 * Handles the display of chips as stacks by their values and translates a given
 * dollar amount into the appropriate amount of each chip type.
 * 
 * <p><strike>TODO: Implement the dollar amount to stacks of chips</strike>
 * <p><strike>TODO: Render stacks based on how many chips are in it</strike>
 * <p><strike>TODO: Add animations for transferring chips from one stack to 
 * another</strike>
 * <p>TODO: Implement some sort of pot display or similar
 * <p>TODO: Make this class a drag-and-drop attractor for adding chips to the 
 * display. For use in the user's betting choices.
 *
 * @author Nikolas Nguyen
 */
public class ChipDisplay extends GameElement {
	protected int value;
	
	// The map relating the number of chips of each chip value (key)
	protected Map<CHIP_VALUE,ChipStack> chipStacks;
	
	/** 
	 * Creates the new chip display with all empty stacks of chips
	 * 
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 * */
	public ChipDisplay(float x, float y, Stage s) {
		super(x, y, s);
		
		// Create an empty stack of chips for each value
		chipStacks = new TreeMap<CHIP_VALUE,ChipStack>();
		float stackX = 0;
		int yPlacer = 0;
		for(CHIP_VALUE value : CHIP_VALUE.values()) {
			ChipStack newStack = new ChipStack(stackX, 128 * (yPlacer % 2), s, value);
			if((yPlacer % 2) == 1) newStack.toBack();
			
			chipStacks.put(value, newStack);
			this.addActor(newStack);
			
			stackX += 64.0f;
			yPlacer += 1;
		}
		
		this.setSize(chipStacks.size() * 64, 256);
	}
	
	/**
	 * Divides the dollar amount given into the a stack of chips using the minimum
	 * total number of chips
	 * 
	 * @param amount - the dollar amount to be broken into chips
	 */
	public void divideToStacks(int amount) {
		// Retrieve all the values of the CHIP_VALUE enum
		List<CHIP_VALUE> values = Arrays.asList(CHIP_VALUE.values());
		
		// Create a new comparator for reverse order sorting using java Collections
		Comparator<CHIP_VALUE> cmp = (CHIP_VALUE v1, CHIP_VALUE v2) -> v2.value() - v1.value();
		Collections.sort(values, cmp);
		
		// Break into stacks
		int remainder = amount;		// The remaining amount to be broken up
		int numberInStack = 0;		// The number of chips for this stack
		for(CHIP_VALUE value : values) {	// Iterate over all chip values
			numberInStack = remainder / value.value();		// Calculate this stack
			remainder = remainder % value.value();			// Calculate remainder
			
			// Add the amount to the stack
			if(chipStacks.containsKey(value))
				chipStacks.get(value).add(numberInStack);
		}
	}
	
	public void transfer(Chip chip) {
		if(chipStacks.containsKey(chip.chipValue))
			chipStacks.get(chip.chipValue).transfer((ChipStack)chip.getParent());
	}
	
	/**
	 * Transfers the given value of chips from the given display to this one. It 
	 * creates a sequence of {@link com.badlogic.scenes.scene2d.Action} objects for
	 * rendering the transfers.
	 * 
	 * <p>TODO: Create some way to enforce the appropriate amount is retrieved in
	 * whatever denominations are available.
	 * 
	 * @param amount
	 * @param chipOrigins
	 */
	public void transfer(int amount, ChipDisplay chipOrigins) {
		// Retrieve all the values of the CHIP_VALUE enum
		List<CHIP_VALUE> values = Arrays.asList(CHIP_VALUE.values());
		
		// Create a new comparator for reverse order sorting using java Collections
		Comparator<CHIP_VALUE> cmp = (CHIP_VALUE v1, CHIP_VALUE v2) -> v2.value() - v1.value();
		Collections.sort(values, cmp);
		
		// Break into stacks
		int remainder = amount;		// The remaining amount to be broken up
		int numberInStack = 0;		// The number of chips for this stack
		for(CHIP_VALUE value : values) {	// Iterate over all chip values
			numberInStack = remainder / value.value();		// Calculate this stack
			remainder = remainder % value.value();			// Calculate remainder
			
			// Add the amount to the stack
			if(chipStacks.containsKey(value) && chipOrigins.chipStacks.containsKey(value)) {
				System.out.println("Transferring " + numberInStack + " " + value.value() + " chips");
				chipStacks.get(value).transfer(numberInStack, chipOrigins.chipStacks.get(value));
			}
		}
	}
	
	public void update() { for(ChipStack stack : chipStacks.values()) stack.update(); }
	
	public int getNumberChips(CHIP_VALUE value) { 
		if(chipStacks.containsKey(value))
			return chipStacks.get(value).size();
		else return 0;
	}
	
	public int getValueSum() {
		// Add the value of each stack (number of chips times their value) to the sum
		int sum = 0;
		for(ChipStack stack : chipStacks.values())
			sum += stack.size() * stack.getValue().value();
		
		return sum;	// Return the sum
	}
	
	/**
	 * This embedded, protected class is just used for organizing movable chips into
	 * stacks based off a single, finalized chip value.
	 * 
	 * <p>TODO: Create some sort of transfer function for shifting chips between pots
	 * and hands.
	 * <p>TODO: Create some sort of attractor which can measure the amount of chips
	 * that have been added (using the aforementioned transfer function?)
	 *
	 * @author Nikolas Nguyen
	 */
	protected class ChipStack extends GameElement {
		private final CHIP_VALUE value;	// The unchangeable value of chips to store
		
		private Stack<Chip> stackChips;	// The list of stack chips
		
		/**
		 * Create the stack at the given location
		 * 
		 * @param x - the x-coordinate of the card
		 * @param y - the y-coordinate of the card
		 * @param s - the stage which updates and renders this card
		 * @param value - the chip value for members of this stack
		 * @param display - the display that this stack belongs to
		 */
		public ChipStack(float x, float y, Stage s, CHIP_VALUE value) {
			super(x, y, s);
			
			this.value = value;
			
			stackChips = new Stack<Chip>();
		}
		
		/**
		 * Add the given number of chips to this stack, but only make the top chip
		 * movable.
		 * 
		 * @param number - the amount of chips to add to the stack
		 */
		public void add(int number) {
			// Set the previous top chip as immovable and reset its position
			if(stackChips.size() > 0) {
				Chip chip = stackChips.get(stackChips.size() - 1);
				chip.setDraggability(false);
				chip.setPosition(0, (stackChips.size() - 1) * 16);
			}
			
			// Add the given number of chips
			for(int i = 0; i < number; i++) {
				// Create a new chip that is immovable
				Chip newChip = new Chip(0, (stackChips.size() * 16), getStage(), value);
				newChip.setDraggability(false);
				stackChips.add(newChip);	// Add this chip to the list
				addActor(newChip);			// Add this chip as a child Actor
			}
			
			// Make the top chip movable
			if(stackChips.size() > 0)
				stackChips.peek().setDraggability(true);
		}

		/** 
		 * Adds the given chip to this stack, updating the mobility
		 * 
		 * <p>TODO: Correct the position of the previous top chip
		 * <p>TODO: Animate the addition
		 * 
		 * @param chip - the {@link Chip} object to add to the stack
		 */
		public void add(Chip chip) {
			if(stackChips.size() > 0) stackChips.peek().setDraggability(false);
			
			stackChips.add(chip);
			if(stackChips.size() > 0) stackChips.peek().setDraggability(true);
		}
		
		/** Delete all the chips from this stack */
		public void clear() { 
			stackChips.clear();
			clearChildren();
		}
		
		/** Update all the chips to make sure their graphics resources are loaded */
		public void update() { for(Chip chip : stackChips) chip.update(); }
		
		/** 
		 * Pops the top chip from the stack. This allows for the stack to act 
		 * according to the user's interaction with the chip that's movable
		 * 
		 * @return The chip element that was at the top of the stack
		 */
		public Chip pop() {
			if(stackChips.size() == 0) return null;
			
			Chip chip = stackChips.pop(); 
			
			if(stackChips.size() > 0)
				stackChips.firstElement().setDraggability(true);
			
			return chip;
		}
		
		/**
		 * @param number - the number of chips to remove from the stack
		 * @return Indicates whether the removal was successful in case the stack
		 * does not contain the necessary number of chips
		 */
		public boolean remove(int number) {
			if(stackChips.size() < number) return false;
			for(int i = 0; i < number; i++) pop();
			return true;
		}
		
		/**
		 * Transfers the top chip from the given stack to this one. The chip will be
		 * animated to move to the top of this stack, and then its parentage is
		 * updated to be a part of this group.
		 * 
		 * <p>TODO: Move the old top of the stack back into position
		 * 
		 * @param stackOrigin - the stack to retrieve the chip from
		 * @return The chip that was transferred
		 */
		public Chip transfer(ChipStack stackOrigin) {
			Chip chip = stackOrigin.pop();
			if(chip == null) return null;
			
			Vector2 deltaPos = this.localToScreenCoordinates(new Vector2(0, 0));
			Vector2 tmp = new Vector2(0, -(stackChips.size() * 16));
			deltaPos.sub(chip.localToScreenCoordinates(tmp));
			chip.addAction(Actions.moveBy(deltaPos.x, -deltaPos.y, 0.25f));
			
			this.add(chip);
			stackChips.peek().setDraggability(false);
			
			chip.toFront();
			RunnableAction updateAction = new RunnableAction();
			updateAction.setRunnable(() -> { stackChips.peek().setDraggability(true); });
			chip.addAction(Actions.after(updateAction));
			
			return chip;
		}
		
		/**
		 * Transfers the number of chips from the given stack to this one. It
		 * iterates through the number transferring only one chip at a time as an 
		 * animation.
		 * 
		 * @param number - the number of chips to transfer
		 * @param stackOrigin - the stack to retrieve the chips from
		 */
		public void transfer(int number, ChipStack stackOrigin) {
			RunnableAction transferAction = new RunnableAction();
			transferAction.setRunnable(() -> { transfer(stackOrigin); });
			
			if(number > 0) this.addAction(transferAction);
			for(int i = 0; i < number; i++) {
				this.addAction(Actions.after(Actions.delay(0.125f)));
				this.addAction(Actions.after(transferAction));
			}
		}
		
		// Get-Set Functions
		public int size() { return stackChips.size(); }
		
		public CHIP_VALUE getValue() { return value; }
	}
}