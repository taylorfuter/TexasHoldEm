package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.utils.Align;

public class DialogBox extends DraggableElement{
	protected ButtonElement closeButton;
	
	public DialogBox(float x, float y, Stage s) {
		super(x, y, s);
		
		closeButton = new ButtonElement(0, 0, getStage(), () -> { close(); });
		closeButton.setText("X");
		closeButton.setScale(0.5f);
		addActor(closeButton);
		
		setSize(closeButton.getHeight(), closeButton.getWidth());
		
		if(texture == null) texture = GameAssets.defaultDialogBoxStyle;
	}
	
	protected void close() {
		removeActor(closeButton);
		remove();
	}

	// Get-Set Functions
	
	@Override
	public void setSize(float width, float height) {
		super.setSize(width + 16, height + 16);
		setOrigin(Align.center);
		closeButton.setPosition(width + 16 - closeButton.getWidth(),
				height + 16 - closeButton.getHeight());
	}
	
	public void setCloseAction(ButtonElement.ButtonAction action) {
		closeButton.setActionPressed(() -> { action.activate(); close(); });
	}
	
	public void setDialogBoxStyle(NinePatchDrawable background) {
		texture = background;
	}
}
