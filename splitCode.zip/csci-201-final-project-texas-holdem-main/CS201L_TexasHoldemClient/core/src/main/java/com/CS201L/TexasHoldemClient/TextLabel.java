package com.CS201L.TexasHoldemClient;

// LibGDX library references
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.utils.Align;

/**
 * 
 *
 * @author Nikolas Nguyen
 */
public class TextLabel extends GameElement {
	protected Label label;
	protected LabelStyle labelStyle;
	
	// Constructors
	/**
	 * Creates a label which renders the text with the game's default style
	 * 
	 * @param x - the x-coordinate of the element
	 * @param y - the y-coordinate of the element
	 * @param s - the stage which updates and renders this element
	 * @param text - the text to display
	 */
	public TextLabel(float x, float y, Stage s, String text) {
		this(x, y, s, text, GameAssets.defaultLabelStyle);
	}

	/**
	 * Creates a label which displays the text using the given font and default color
	 * 
	 * @param x - the x-coordinate of the element
	 * @param y - the y-coordinate of the element
	 * @param s - the stage which updates and renders this element
	 * @param text - the text to display
	 * @param font - the font to use with the game's default font color
	 */
	public TextLabel(float x, float y, Stage s, String text, BitmapFont font) {
		this(x, y, s, text, new LabelStyle(font, GameAssets.defaultLabelStyle.fontColor));
	}
	
	/**
	 * Creates a label which displays the text with the game's default font, but with
	 * the color provided
	 * 
	 * @param x - the x-coordinate of the element
	 * @param y - the y-coordinate of the element
	 * @param s - the stage which updates and renders this element
	 * @param text - the text to display
	 * @param color - the color to use with the game's default font
	 */
	public TextLabel(float x, float y, Stage s, String text, Color color) {
		this(x, y, s, text, new LabelStyle(GameAssets.defaultFont, color));
	}
	
	/**
	 * Creates a new label using the given font to render the text
	 * 
	 * @param x - the x-coordinate of the element
	 * @param y - the y-coordinate of the element
	 * @param s - the stage which updates and renders this element
	 * @param text - the text to display
	 * @param style - the font style for rendering the text
	 */
	public TextLabel(float x, float y, Stage s, String text, LabelStyle style) {
		super(x, y, s);
		
		labelStyle = style;
		label = new Label(text, labelStyle);
		label.setOrigin(Align.center);
		
		setSize(label.getWidth(), label.getHeight());
		addActor(label);
	}
	
	// Get-Set Functions
	public LabelStyle getLabelStyle() { return labelStyle; }
	
	public void setLabelStyle(LabelStyle style) { labelStyle = style; }
	
	public void setColor(Color color) {
		label.setColor(color);
	}
	
	public void setText(String text) { 
		label.setText(text);
		label.pack();
		setSize(label.getWidth(), label.getHeight());
	}
}
