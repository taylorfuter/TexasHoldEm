package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;
import com.badlogic.gdx.utils.Align;

/**
 * Creates a card game element that can be dragged and displays the card face
 * by translating an integer value to the texture path.
 *
 * @author Nikolas Nguyen
 */
public class Card extends DraggableElement {
	public Integer cardValue;	// The integer value of the card
	
	float startX;
	float startY;
	
	public boolean bLoaded;
	public boolean bReturnCard; // Returns card to wherever it started when dragged
	
	/** 
	 * Creates a new card at the given position with a default display of the back
	 * 
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 */
	public Card(float x, float y, Stage s) { 
		super(x, y, s);
		cardValue = -1;
		
		bLoaded = false;
	}
	
	/**
	 * Creates a new card at the given position which displays the given value
	 * <pre> ( 0-12) = (Ace - King) of Spades
	 * (13-25) = (Ace - King) of Hearts
	 * (26-38) = (Ace - King) of Clubs
	 * (39-51) = (Ace - King) of Diamonds </pre>
	 * 
	 * @param x - the x-coordinate of the card
	 * @param y - the y-coordinate of the card
	 * @param s - the stage which updates and renders this card
	 * @param card - the integer value of the card to be displayed
	 */
	public Card(float x, float y, Stage s, Integer card) {
		super(x, y, s);
		cardValue = card;
		bLoaded = false;
		bReturnCard = false;
	}
	
	public void act(float dt) { super.act(dt); }
	
	public void flip() {
		addAction(Actions.after(Actions.scaleTo(0, 1.125f, 0.25f)));
		
		RunnableAction texChange = new RunnableAction();
		texChange.setRunnable(() -> { texture = null; loadTexture(); });
		addAction(Actions.after(texChange));
		addAction(Actions.after(Actions.scaleTo(1, 1, 0.25f)));
	}
	
	public void load() {
		if(!isLoaded()) {
			if(texture != null) flip();
			else loadTexture();
		}
		bLoaded = true;
	}
	
	/** Loads the texture of the card for rendering */
	public void loadTexture() {	
		if(texture != null) return;
		if(cardValue < 0) { 					// Display the back
			loadTexture("cards/cards_png_zip/PNG/blue_back.png");
			setSize(256, 360);
			setOrigin(Align.center);
			bLoaded = true;
			return;
		}
		
		// Create a StringBuffer to create the texture path
		StringBuffer strBuf = new StringBuffer("cards/cards_png_zip/PNG/");
		
		// Determine the rank
		int rank = (cardValue % 13) + 1;
		switch(rank) {
		case 1: strBuf.append("A"); break;
		case 11: strBuf.append("J"); break;
		case 12: strBuf.append("Q"); break;
		case 13: strBuf.append("K"); break;
		default: strBuf.append(rank); break;
		}
		
		// Determine the suit
		switch(cardValue / 13) {
		case 0: strBuf.append("S"); break;
		case 1: strBuf.append("H"); break;
		case 2: strBuf.append("C"); break;
		case 3: strBuf.append("D"); break;
		default: 
			loadTexture("cards/joker.jpg");	// If unrecognized, display the joker
			bLoaded = true;
			return;
		}
		
		strBuf.append(".png");					// Add the filetype (.png)
		
		loadTexture(strBuf.toString());	// Load the texture for the given path
		
		setSize(256, 360);
		setOrigin(Align.center);
	}
	
	@Override
	public void onDragStart() {
		startX = getX();
		startY = getY();
	}
	
	public void onDrop() {
		if(bReturnCard) addAction(Actions.moveTo(startX, startY, 0.125f));
	}
	
	// Get-Set functions
	public boolean isLoaded() { return bLoaded; }
	
	public String getRankString() {
		int value = (cardValue % 13) + 1;
		switch((cardValue % 13) + 1) {
		case 1: return "Ace";
		case 11: return "Jack";
		case 12: return "Queen";
		case 13: return "King";
		default: return Integer.toString(value);
		}
	}
	
	public String getSuitString() { 
		switch(cardValue / 13) {
		case 0: return "Spades";
		case 1: return "Hearts";
		case 2: return "Clubs";
		case 3: return "Diamonds";
		default: return "Joker";
		}
	}
	
	public void setCardValue(Integer cardValue) {
		this.cardValue = cardValue;
		bLoaded = false;
	}
}
