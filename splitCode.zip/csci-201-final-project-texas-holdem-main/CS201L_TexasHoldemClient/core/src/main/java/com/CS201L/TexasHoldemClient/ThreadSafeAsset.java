package com.CS201L.TexasHoldemClient;

/**
 * <font color="red">(!!UNIMPLEMENTED!!)</font> - Meant to replace the thread-safe
 * functionality inside {@link GameElement} since not all client-side assets are
 * updated by separate threads like those on the client-server connection. The asset
 * must contain a {@code load()} function which should generally only be called if
 * the asset is not currently loaded for running inside the thread that handles all
 * the graphics assets (namely the one with an OpenGL device assigned to it by
 * libGDX)
 * 
 * <p>TODO: Implement
 *
 * @author Nikolas Nguyen
 */
public interface ThreadSafeAsset {
	/** Called to safely load the graphics resources */
	public void load();
	
	/** @return Whether the thread safe resources need by libGDX are loaded */
	public boolean isLoaded();
	
	/** Forces the resource to mark itself loaded or not */
	public void setLoaded(boolean loaded);
}
