package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.ArrayList;
import java.util.List;
// LibGDX library references
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;
import com.badlogic.gdx.utils.Align;

/**
 * This class is used for arranging the community cards on the table for poker. It
 * stores the {@link GameElement} objects representing the cards and sets their 
 * position and rotation on the board.
 * 
 * <p><strike>TODO: Correct the position and rotation of the display and the cards so
 * that they are oriented based on the center rather than the bottom left corner for
 * easier layout.</strike>
 * <p><strike>TODO: Make this a child of 
 * {@link com.badlogic.gdx.scenes.scene2d.Group}, so that it can parent the player
 * cards for easier management of position, rotation, scale, etc.</strike>
 * <p>TODO: Create a resizing functionality for minimally overlapping or cycling
 * through cards.
 * <p>TODO: Render the pot as immovable chips
 * <p><strike>TODO: Render a draw pile and a burn pile</strike>
 * <p><strike>TODO: Create animations for burning, dealing, & flipping.</strike>
 * <p>TODO: Make an optional burn reveal
 *
 * @author Nikolas Nguyen
 */
public class PokerCommunityCardDisplay 
		extends GameElement implements ThreadSafeAsset {
	public GameElement drawPile;
	public Card topCard;
	public Card burnPile;
	public List<Card> cards;	// The list of cards in the community
	
	public boolean bLoaded;
	
	// Constructors
	public PokerCommunityCardDisplay(float x, float y, Stage s) { 
		this(x, y, s, 1312.0f, 320.0f, 0.0f);
	}
	
	/**
	 * This is the basic constructor for setting up the display in screen space and
	 * the stage which it and all its cards will belong to.
	 * 
	 * @param x- the x-coordinate for the display
	 * @param y - the y-coordinate of the display
	 * @param s - the stage that holds the card assets
	 * @param width - the display width
	 * @param height - the display height
	 * @param rotation - the rotation of the display
	 */
	public PokerCommunityCardDisplay(float x, float y, Stage s, float width,
			float height, float rotation) {
		super(x, y, s);
		cards = new ArrayList<Card>(5);	// There will only ever be 5 table cards
		
		setSize(width, height);
		setOrigin(Align.center);
		setRotation(rotation);
		
		drawPile = new GameElement(-(width / 2.0f) - 256, -64, s);
		//drawPile.loadTexture("draw_pile.jpg");
		addActor(drawPile);
		
		topCard = new Card(drawPile.getX(), 0, s);
		addActor(topCard);
		
		bLoaded = false;
	}
	
	/**
	 * To be called whenever the screen is resized or the display is updated to make
	 * sure the community cards are laid out evenly 
	 */
	public void resize() { }
	
	/** Updates each of the cards to match the texture if not loaded */
	public void update() { if(!isLoaded()) load(); }
	
	// Dealing functions
	
	private void addCard(float x, float y, int cardValue) {
		Card addCard = topCard;
		
		RunnableAction flipAction = new RunnableAction();
		flipAction.setRunnable(() -> { addCard.setCardValue(cardValue);	});
		
		addCard.addAction(Actions.moveTo(x, y, 0.5f));
		addCard.addAction(Actions.after(Actions.delay(0.25f)));
		addCard.addAction(Actions.after(flipAction));
		
		addCard.toFront();
		addCard.bReturnCard = true;
		cards.add(addCard);
		
		topCard = new Card(drawPile.getX(), 0, getStage(), -1);
		this.addActor(topCard);
		
		bLoaded = false;
	}
	
	public void dealBurn() { 
		Card addCard = topCard;
		
		addCard.addAction(Actions.moveBy(0, 350.0f, 0.5f));
		
		addCard.toFront();
		addCard.setDraggability(false);
		addCard.bReturnCard = true;
		
		topCard = new Card(drawPile.getX(), 0, getStage(), -1);
		this.addActor(topCard);
	}
	
	/**
	 * Deals the flop of three cards for display
	 * 
	 * @param cardValue1 - the first card value dealt
	 * @param cardValue2 - the second card value dealt
	 * @param cardValue3 - the second card value dealt
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 * 
	 */
	public void dealFlop(int cardValue1, int cardValue2, int cardValue3) {
		// Only fill in these cards if they don't already exist
		this.addAction(Actions.delay(0.125f));
		
		RunnableAction addCardAction;
		
		float x = (-getWidth() / 2.0f) + 128.0f;
		if(cards.size() < 1) {
			addCardAction = new RunnableAction();
			final float x1 = x;
			addCardAction.setRunnable(() -> { addCard(x1, 0, cardValue1); });
			addAction(Actions.after(addCardAction));
			addAction(Actions.after(Actions.delay(0.125f)));
			
			x += getWidth() / 5.0f;
			addCardAction = new RunnableAction();
			final float x2 = x;
			addCardAction.setRunnable(() -> { addCard(x2, 0, cardValue2); });
			addAction(Actions.after(addCardAction));
			addAction(Actions.after(Actions.delay(0.125f)));
			
			x += getWidth() / 5.0f;
			addCardAction = new RunnableAction();
			final float x3 = x;
			addCardAction.setRunnable(() -> { addCard(x3, 0, cardValue3); });
			addAction(Actions.after(addCardAction));
			addAction(Actions.after(Actions.delay(0.125f)));
		}
	}
	
	/**
	 * Deals the river card for display
	 * 
	 * @param cardValue - the value of the river card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 * 
	 */
	public void dealRiver(int cardValue) {
		// Only fill in this card if it doesn't already exist
		if(cards.size() == 4) {
			addCard(-(getWidth() / 2.0f) + 128.0f + (4.0f * (getWidth() / 5.0f)), 0, cardValue);
			System.out.println("Dealing River!");
		}
	}
	
	/**
	 * Deals the turn card for display
	 * 
	 * @param cardValue - the value of the turn card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 */
	public void dealTurn(int cardValue) {
		// Only fill in this card if it doesn't already exist
		if(cards.size() == 3) {
			addCard(-(getWidth() / 2.0f) + 128.0f + (3.0f * (getWidth() / 5.0f)), 0, cardValue);
			System.out.println("Dealing Turn!");
		}
	}

	public Card takeTopCard() {
		Card card = topCard;
		topCard = new Card(drawPile.getX(), 0, getStage());
		addActor(topCard);
		topCard.toFront();
		//removeActor(card);
		card.toFront();
		return card;
	}
	
	@Override
	public void load() {
		if(!topCard.isLoaded()) topCard.load();
		for(Card c : cards) if(!c.isLoaded()) c.load();
		bLoaded = true;
	}
	
	@Override
	public boolean isLoaded() {
		for(Card c : cards) if(!c.isLoaded()) return false;
		return bLoaded; 
	}

	@Override
	public void setLoaded(boolean loaded) { bLoaded = loaded; }
}
