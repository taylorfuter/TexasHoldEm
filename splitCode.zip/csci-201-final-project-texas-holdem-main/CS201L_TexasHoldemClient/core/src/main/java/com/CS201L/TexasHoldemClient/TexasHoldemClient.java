package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import com.CS201L.TestingSuite.DisplayTest;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class TexasHoldemClient extends BaseGame {
	public DisplayTest display;			// The screen that implements the poker game
	public PokerScreen pokerTest;
	private Viewport viewport;			// The viewport of the window
	private OrthographicCamera camera;	// The orthographic camera used for rendering
	
	@Override
	public void create() {
		super.create();
		
		GameAssets.ButtonStyle style = new GameAssets.ButtonStyle();
		style.up = GameAssets.loadNinePatch("button_9patch.png");
		style.down = GameAssets.loadNinePatch("buttonPressed_9patch.png");
		style.over = GameAssets.loadNinePatch("buttonHover_9patch.png");
		GameAssets.setGameDefaultButtonStyle(style);
		GameAssets.setGameDefaultFont(new BitmapFont(Gdx.files.internal("bahnschrift.fnt")));
		
		GameAssets.setGameDefaultDialogBoxStyle(GameAssets.loadNinePatch("button_9patch.png"));
		
		TextField.TextFieldStyle fieldStyle = new TextField.TextFieldStyle();
		fieldStyle.background = GameAssets.loadNinePatch("textfield_9patch.png");
		fieldStyle.font = GameAssets.defaultFont;
		fieldStyle.fontColor = Color.BLACK;
		TextField.TextFieldStyle errorFieldStyle = new TextField.TextFieldStyle();
		errorFieldStyle.background = GameAssets.loadNinePatch("textfieldError_9patch.png");
		errorFieldStyle.font = GameAssets.defaultFont;
		errorFieldStyle.fontColor = Color.BLACK;
		
		GameAssets.setGameDefaultFieldStyle(fieldStyle);
		GameAssets.setGameDefaultErrorFieldStyle(errorFieldStyle);
		
		// Create the camera of the specified window size and match the viewport
		
		int width = Gdx.graphics.getWidth();
		int height = Gdx.graphics.getHeight();
		float ratio = width / height;
		if(ratio > 2) width = height * 2;
		else height = width / 2;
		
		System.out.println("Screen: " + width + "x" + height);
		
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 2048, 1024);
		viewport = new FitViewport(2048, 1024);
		viewport.apply(true);
		
		setActiveScreen(new MenuScreen(viewport));
	}
	
	@Override
	public void resize(int width, int height) {
		viewport.update(width, height);
		camera.update();
	}
}