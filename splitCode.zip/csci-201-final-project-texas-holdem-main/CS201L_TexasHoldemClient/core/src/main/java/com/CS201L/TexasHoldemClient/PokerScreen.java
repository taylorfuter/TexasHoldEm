package com.CS201L.TexasHoldemClient;

// Java library references
import java.util.Map;
import java.util.TreeMap;

import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.Viewport;

/**
 * Creates a new screen for the application that runs the logic and rendering for a
 * game of poker.
 * 
 * <p>TODO: Add the screen switches between buttons, betting, rounds, and win logic
 * <p>TODO: Add the dealer button
 * <p>TODO: Add a betting player indicator
 * <p>TODO: Create resizing functionality for swapping between opponent displays when
 * the screen is too small.
 * <p>TODO: Create a small user's hand and community card unicode emoji & text 
 * display for making cards visible in small windows.
 *
 * @author Nikolas Nguyen
 */
public class PokerScreen extends BaseScreen {
	BaseScreen prevScreen;
	
	protected PokerClient client;					// The client connection for the user
	protected PokerCommunityCardDisplay community;	// The display for table cards
	protected PokerPlayerCardDisplay player;		// The display for the user
	protected BettingHUD playerBetHUD;
	protected GameElement dealerButton;
	
	// A list of all player displays mapped to their player ID
	protected Map<Integer,PokerPlayerCardDisplay> opponents;
	
	// The assets used for backgrounds and UI
	private GameElement felt;		// The felt background
	
	public PokerScreen(Viewport viewport, BaseScreen prevScreen, PokerClient client) {
		super(viewport);
		this.prevScreen = prevScreen;
		this.client = client;
	}
	
	@Override
	public void initialize() {		
		opponents = new TreeMap<Integer,PokerPlayerCardDisplay>();
		
		felt = new GameElement(0, 0, mainStage);
		felt.loadTexture("felt_poker.jpg");
		felt.toBack();
		
		dealerButton = new GameElement(1024, 900, mainStage);
		dealerButton.setTexture(GameAssets.loadTexture("chips/dealer_button.png"));
		dealerButton.setSize(96, 96);
		dealerButton.toFront();
	}
	
	@Override
	public void update(float dt) {
		/** Try to open the client if it hasn't yet been initialized*/
		if(client == null) {
			this.createErrorMessageBox("No server connection");
			BaseGame.setActiveScreen(new MenuScreen(viewport));
		}
		
		if(community != null) community.update();
		if(player != null) player.update();
		if(playerBetHUD != null) playerBetHUD.update();
		for(PokerPlayerCardDisplay display : opponents.values()) display.update();
	}
	
	/** Add the community cards to the screen display */
	public void addCommunity() {
		System.out.println("Creating community cards");
		community = new PokerCommunityCardDisplay(1024, 650, mainStage);
	}
	
	/**
	 * Add an opponent to display at the table with the given player ID 
	 * 
	 * @param id - the unique ID of the opponent player 
	 * */
	public void addOpponent(Integer id) {
		PokerPlayerCardDisplay opponent;
		if(opponents.size() == 0)
			opponent = new PokerPlayerCardDisplay(800, 32, mainStage, 0);
		else if(opponents.size() == 1)
			opponent = new PokerPlayerCardDisplay(-200, 240, mainStage, -30);
		else if(opponents.size() == 2)
			opponent = new PokerPlayerCardDisplay(1300, 64, mainStage, 30);
		else return;
		opponent.setScale(0.75f);
		opponent.setOpponentMode(true);
		opponents.put(id, opponent);
		if(player != null) player.toFront();
	}
	
	/** Add the user's player to the display */
	public void addPlayer() {
		player = new PokerPlayerCardDisplay(350, 20, mainStage, 0);
		player.setScale(0.8f);
		player.toFront();
		
		playerBetHUD = new BettingHUD(2304, 48, uiStage, client);
	}
	
	@Override
	public void createErrorMessageBox(String message) {
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox errMsg = new MessageBox(0, 0, uiStage, "Error", message);
		errMsg.setPosition(x, y, Align.center);
	}
	
	public void createEndGameMessageBox(String message) {
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox endMsg = new MessageBox(0, 0, uiStage, "End of Game", message);
		endMsg.setPosition(x, y, Align.center);
		endMsg.setOKAction(() -> {
			//client.close();
			BaseGame.setActiveScreen(new MenuScreen(viewport));
		});
	}
	
	// Dealing functions
	
	/**
	 * Deals the flop of three cards to the display
	 * 
	 * @param cardValue1 - the first card value dealt
	 * @param cardValue2 - the second card value dealt
	 * @param cardValue3 - the second card value dealt
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 * 
	 */
	public void dealFlop(int cardValue1, int cardValue2, int cardValue3) {
		community.dealFlop(cardValue1, cardValue2, cardValue3);
	}
	
	/**
	 * Deals the river card to the display
	 * 
	 * @param cardValue - the value of the river card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 * 
	 */
	public void dealRiver(int cardValue) { community.dealRiver(cardValue); }
	
	/**
	 * Deals the turn card to the display
	 * 
	 * @param cardValue - the value of the turn card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 * 
	 */
	public void dealTurn(int cardValue) { community.dealTurn(cardValue); }
	
	/**
	 * Deals a hidden card (value -1) to the opponent of the given ID to the display
	 * 
	 * @param id - the ID of the opponent player
	 */
	public void dealOpponent(Integer id) {
		if(opponents.containsKey(id))
			opponents.get(id).addPrivateCard(community.takeTopCard());
	}
	
	/**
	 * Deals a visible card in the user's hand to the display
	 * 
	 * @param cardValue - the value of the river card
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 */
	public void dealPlayer(Integer cardValue) { 
		if(player != null) player.addPublicCard(community.takeTopCard(), cardValue);
	}
	
	public void disableBettingHUD() {
		playerBetHUD.addAction(Actions.moveTo(2304, 48, 0.5f));
	}
	
	public void enableBettingHUD() {
		RunnableAction enableAction = new RunnableAction();
		enableAction.setRunnable(() -> {
			playerBetHUD.enableInput(true, true, false, true);
		});
		
		playerBetHUD.addAction(Actions.moveTo(1280, 48, 0.5f));
		playerBetHUD.addAction(Actions.after(enableAction));
	}
	
	public void foldOpponent(int id) {
		if(opponents.containsKey(id))
			opponents.get(id).fold();
	}
	
	public void foldPlayer() { player.fold(); }
	
	/** 
	 * Reveals the card values of the given opponent to the displays
	 * 
	 * @param id - the ID of the opponent player
	 * @param cardValue1 - the integer value of the first card in their hand
	 * @param cardValue2 - the integer value of the second card in their hand
	 * 
	 * @see {@link Card} for understanding integer to card suit and rank
	 * 
	 */
	public void revealOpponent(Integer id, Integer cardValue1, Integer cardValue2) {
		if(opponents.containsKey(id))
			opponents.get(id).reveal(cardValue1, cardValue2);
	}
	
	public void setDealerOpponent(int id) {
		if(dealerButton == null || opponents == null) return;
		
		PokerPlayerCardDisplay opp = opponents.get(id);	
		if(opp == null) return;
		dealerButton.addAction(Actions.moveTo(opp.getX() + 128,
				opp.getTop() + 16, 0.5f));
	}
	
	public void setDealerPlayer() {
		if(dealerButton == null || player == null) return;
		
		dealerButton.addAction(Actions.moveTo(player.getX() + 128,
				player.getTop() + 16, 0.5f));
	}
}
