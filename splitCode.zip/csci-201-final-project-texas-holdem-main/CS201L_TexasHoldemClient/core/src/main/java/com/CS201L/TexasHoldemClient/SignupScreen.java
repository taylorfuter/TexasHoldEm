package com.CS201L.TexasHoldemClient;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.viewport.Viewport;

public class SignupScreen extends BaseScreen {
	protected LoginScreen prevScreen;		// The previous screen for going back
	
	protected TextEntry usernameEntry;
	protected TextEntry passwordEntry;
	protected TextEntry passwordReEntry;
	
	protected ButtonElement signupButton;	// For running a login request
	protected ButtonElement cancelButton;	// For bringing focus back to last screen
	
	protected PokerClient client;
	
	/**
	 * @param prevScreen - the screen that is entering the login so that the user can
	 * go back to where they started
	 */
	public SignupScreen(Viewport viewport, PokerClient client) {
		super(viewport);
		if(client != null) this.prevScreen = client.getLoginScreen();
		this.client = client;
	}
	
	@Override
	public void createErrorMessageBox(String message) {
		float x = uiStage.getWidth() / 2;
		float y = uiStage.getHeight() / 2;
		MessageBox errMsg = new MessageBox(0, 0, uiStage, "Error", message);
		errMsg.setPosition(x, y, Align.center);
		errMsg.setCancelAction(() -> { new MenuScreen(viewport); });
		errMsg.setCloseAction(() -> { new MenuScreen(viewport); });
		
		signupButton.clearActionPressed();
		cancelButton.clearActionPressed();
	}
	
	@Override
	public void initialize() {
		// Create the background image
		new GameElement(0, 0, mainStage).loadTexture("Login.jpg");
		
		TextField.TextFieldStyle style = new TextField.TextFieldStyle();
		style.background = GameAssets.loadNinePatch("textfield_9patch.png");
		style.font = GameAssets.defaultFont;
		style.fontColor = Color.BLACK;
		
		// Initialize a field for the user to enter their username
		usernameEntry = new TextEntry(0, 0, uiStage);
		usernameEntry.getTextField().setMaxLength(15);
		usernameEntry.getTextField().setFocusTraversal(true);
		usernameEntry.setWidth(750);
		usernameEntry.setScale(0.75f);
		
		// Initialize a field for the user to enter their password
		passwordEntry = new TextEntry(0, 0, uiStage);
		passwordEntry.getTextField().setPasswordMode(true);	// Make sure it's hidden
		passwordEntry.getTextField().setPasswordCharacter('�');
		passwordEntry.getTextField().setMaxLength(20);
		passwordEntry.getTextField().setFocusTraversal(true);
		passwordEntry.setWidth(750);
		passwordEntry.setScale(0.75f);
		
		passwordReEntry = new TextEntry(0, 0, uiStage);
		passwordReEntry.getTextField().setPasswordMode(true);	// Make sure it's hidden
		passwordReEntry.getTextField().setPasswordCharacter('�');
		passwordReEntry.getTextField().setMaxLength(20);
		passwordReEntry.setWidth(750);
		passwordReEntry.setScale(0.75f);
		
		TextLabel usernameLabel = new TextLabel(0, 0, uiStage, "Username: ", Color.WHITE);
		usernameLabel.setScale(0.75f);
		
		// The label that will also act as a parent for the visibility button
		TextLabel passwordLabel = new TextLabel(0, 0, uiStage, "Password: ", Color.WHITE);
		passwordLabel.setScale(0.75f);
		
		TextLabel passwordCheckLabel = new TextLabel(0, 0, uiStage, "Re-enter: ", Color.WHITE);
		passwordCheckLabel.setScale(0.75f);
		
		// Prepare the login button which submits the login request when pressed
		signupButton = new ButtonElement(0, 0, uiStage);
		signupButton.setPosition(0, 0, Align.center);
		signupButton.setText("Sign Up");
		signupButton.setActionPressed(() -> { sendSignupRequest(); });
		
		// Initialize a button which toggles password visibility when held
		ButtonElement passwordVisibilityButton = new ButtonElement(0, 0, uiStage);
		GameElement visibilityIcon = new GameElement(0, 0, uiStage);
		visibilityIcon.loadTexture("visibility.png");
		passwordVisibilityButton.setIcon(visibilityIcon);
		passwordVisibilityButton.setActionPressed(() -> { 
			passwordEntry.getTextField().setPasswordMode(false);	// Make the password visible
		});
		passwordVisibilityButton.setActionReleased(() -> {
			passwordEntry.getTextField().setPasswordMode(true);	// Make it invisible again
		});
		passwordEntry.addActor(passwordVisibilityButton);
		passwordVisibilityButton.setPosition(
				passwordEntry.getWidth() - (passwordVisibilityButton.getWidth() / 2) - 16,
				passwordEntry.getOriginY(), Align.center);
		passwordLabel.toFront();	// Bring it to the front so it can be pressed
		
		passwordVisibilityButton = new ButtonElement(0, 0, uiStage);
		visibilityIcon = new GameElement(0, 0, uiStage);
		visibilityIcon.loadTexture("visibility.png");
		passwordVisibilityButton.setIcon(visibilityIcon);
		passwordVisibilityButton.setActionPressed(() -> { 
			passwordReEntry.getTextField().setPasswordMode(false);	// Make the password visible
		});
		passwordVisibilityButton.setActionReleased(() -> {
			passwordReEntry.getTextField().setPasswordMode(true);	// Make it invisible again
		});
		passwordReEntry.addActor(passwordVisibilityButton);
		passwordVisibilityButton.setPosition(
				passwordReEntry.getWidth() - (passwordVisibilityButton.getWidth() / 2) - 16,
				passwordReEntry.getOriginY(), Align.center);
		
		// Prepare the cancel button which will bring the user back when pressed
		cancelButton = new ButtonElement(0, 0, uiStage);
		cancelButton.setText("Cancel");;
		cancelButton.setActionPressed(() -> { BaseGame.setActiveScreen(prevScreen); });
		
		// Create a table for organizing the layout of the login information
		Table loginTable = new Table();
		loginTable.setFillParent(true);
		uiStage.addActor(loginTable);
		
		// Create the table row for username info
		loginTable.add(usernameLabel).right();
		loginTable.add(usernameEntry);
		
		// Create the table row for the password info
		loginTable.row();
		loginTable.add(passwordLabel).right();
		loginTable.add(passwordEntry);
		
		loginTable.row();
		loginTable.add(passwordCheckLabel).right().prefWidth(100);
		loginTable.add(passwordReEntry);
		
		// Create the row for the buttons
		loginTable.row();
		loginTable.add(signupButton).right().prefWidth(signupButton.getWidth());
		loginTable.add(cancelButton).center().prefWidth(cancelButton.getWidth());
	}

	@Override
	public void update(float dt) { }

	/**
	 * Perform the login request from the user's input. 
	 * 
	 * <p>TODO: Add the hashing function somewhere
	 * <p>TODO: Connect to the login database
	 * <p>TODO: 
	 * */
	public void sendSignupRequest() {
		String username = usernameEntry.getText();
		String password = passwordEntry.getText();
		
		if(client == null) { BaseGame.setActiveScreen(prevScreen); return; }
		
		usernameEntry.setErrorMode(false);
		passwordEntry.setErrorMode(false);
		passwordReEntry.setErrorMode(false);
		if(username.equals("")) usernameEntry.flagError("A username is required");
		else if(password.equals("")) passwordEntry.flagError("A password is required");
		else if(!password.equals(passwordReEntry.getText())) 
			passwordReEntry.flagError("Passwords do not match");
		else client.echoServer("signup " + username + " " + password);
	}
}
