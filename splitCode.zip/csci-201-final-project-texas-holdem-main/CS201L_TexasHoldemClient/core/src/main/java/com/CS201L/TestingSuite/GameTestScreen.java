package com.CS201L.TestingSuite;

import com.CS201L.TexasHoldemClient.BaseScreen;
import com.CS201L.TexasHoldemClient.CardPile;
import com.CS201L.TexasHoldemClient.PokerPlayerCardDisplay;
import com.CS201L.TexasHoldemClient.PokerScreen;
import com.badlogic.gdx.utils.viewport.Viewport;

public class GameTestScreen extends PokerScreen {
	CardPile drawPile;
	
	public GameTestScreen(Viewport viewport, BaseScreen prevScreen) {
		super(viewport, prevScreen, null);
		drawPile = new CardPile();
		new Thread(() -> { run(); }).start();
	}
	
	@Override
	public void update(float dt) {
		if(community != null) community.update();
		if(player != null) player.update();
		if(playerBetHUD != null) playerBetHUD.update();
		for(PokerPlayerCardDisplay display : opponents.values()) display.update();
	}
	
	public void run() {
		System.out.println("Adding table cards");
		addCommunity();
		
		try { Thread.sleep(500); } catch(Exception e) { e.printStackTrace(); }
		System.out.println("Adding player");
		addPlayer();
		
		for(int i = 1; i < 4; i++) {
			try { Thread.sleep(500); } catch(Exception e) { e.printStackTrace(); }
			System.out.println("Adding opponent " + i);
			addOpponent(i);
		}
		
		for(int i = 0; i < 2; i++) {
			int card = drawPile.deal();
			System.out.println("Dealing player (card " + card + ")");
			dealPlayer(card);
			
			for(int j = 1; j < 4; j++) {
				try { Thread.sleep(500); } catch(Exception e) { e.printStackTrace(); }
				System.out.println("Dealing opponent " + j);
				dealOpponent(j);
			}
			try { Thread.sleep(500); } catch(Exception e) { e.printStackTrace(); }
		}
		
		System.out.println("Player @ (" + player.getX() + ", " + player.getY() + ")");
		System.out.println("Player: \n" + player);
		for(PokerPlayerCardDisplay opp : opponents.values()) {
			System.out.println("Opponent @ (" + opp.getX() + ", " + opp.getY() + ")");
			System.out.println("Opponent: \n" + player);
		}
		
		this.dealFlop(drawPile.deal(), drawPile.deal(), drawPile.deal());
		try { Thread.sleep(500); } catch(Exception e) { e.printStackTrace(); }		
		
		this.setDealerPlayer();
		
		this.playerBetHUD.setWallet(1000);
		this.playerBetHUD.setPotValue(30);
		this.playerBetHUD.setCurrentBet(10);
		this.playerBetHUD.setMinRaise(15);
		enableBettingHUD();
		
		try { Thread.sleep(500); } catch(Exception e) { e.printStackTrace(); }
		System.out.println("Button: " + dealerButton.getX() + ", " + dealerButton.getY());
		
		this.revealOpponent(1, drawPile.deal(), drawPile.deal());
		
		this.foldOpponent(1);
	}
}
