package com.CS201L.MyGDKGame;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Array;

public class GameElement extends Group {
	// Physics members
	private Vector2 velocity;
	private Vector2 acceleration;
	
	// Animation members
	private Animation<TextureRegion> animation;
	private float deltaTime;
	private boolean bAnimPause;
	
	// Constructor
	public GameElement(float x, float y, Stage s) {
		super();
		setPosition(x, y);
		s.addActor(this);
		
		acceleration = new Vector2(0, 0);
		velocity = new Vector2(0, 0);
		
		animation = null;
		deltaTime = 0;
		bAnimPause = false;
	}

	// Game engine functions
	public void act(float dt) {
		super.act(dt);
		if(!bAnimPause) deltaTime += dt;
	}
	public void draw(Batch batch, float parentAlpha) {
		Color c = getColor();
		batch.setColor(c.r, c.g, c.b, c.a);
		
		if(animation != null && isVisible())
			batch.draw(animation.getKeyFrame(deltaTime), getX(), getY());
		
		super.draw(batch, parentAlpha);
	}
	
	// State update functions for overriding in child classes
	public void onPause() {
		return;
	}
	public void onResume() {
		return;
	}
	
	// Resource loading functions
	public Animation<TextureRegion> loadAnimationFromImageAtlas(String filename, int rows,
			int columns, float frameDuration, boolean loop) {
		Texture texture = new Texture(Gdx.files.internal(filename));
		texture.setFilter(TextureFilter.Linear, TextureFilter.Linear);
		int frameWidth = texture.getWidth() / columns;
		int frameHeight = texture.getHeight() / rows;
		
		TextureRegion[][] temp = TextureRegion.split(texture, frameWidth, frameHeight);
		Array<TextureRegion> textureArray = new Array<TextureRegion>();
		for(int i = 0; i < frameHeight; i++) 
			for(int j = 0; j < frameWidth; j++)
				textureArray.add(temp[i][j]);
		
		Animation<TextureRegion> anim = new Animation<TextureRegion>(frameDuration,
				textureArray);
		if(loop) anim.setPlayMode(Animation.PlayMode.LOOP);
		else anim.setPlayMode(Animation.PlayMode.NORMAL);
		
		if(animation == null) animation = anim;
		
		return anim;
	}
	public Animation<TextureRegion> loadAnimationFromImageSequence(String[] fileNames, 
			float frameDuration, boolean loop) {
		int fileCount = fileNames.length;
		Array<TextureRegion> textureArray = new Array<TextureRegion>();
		
		for(int i = 0; i < fileCount; i++) {
			String filename = fileNames[i];
			Texture texture = new Texture(Gdx.files.internal(filename));
			texture.setFilter(TextureFilter.Linear, TextureFilter.Linear);
			textureArray.add(new TextureRegion(texture));
		}
		
		Animation<TextureRegion> anim = new Animation<TextureRegion>(frameDuration,
				textureArray);
		if(loop) anim.setPlayMode(Animation.PlayMode.LOOP);
		else anim.setPlayMode(Animation.PlayMode.NORMAL);
		
		if(animation == null) animation = anim;
		
		return anim;
	}
	public Animation<TextureRegion> loadTexture(String filename) {
		String[] fileNames = new String[1];
		fileNames[0] = filename;
		
		return loadAnimationFromImageSequence(fileNames, 1, true);
	}
	
	// Get-Set Functions
	public static ArrayList<GameElement> getList(Stage stage,
			Class<? extends GameElement> elementClass) {
		ArrayList<GameElement> list = new ArrayList<GameElement>();
		
		for(Actor a : stage.getActors())
			if(elementClass.isInstance(a))
				list.add((GameElement)a);
		
		return list;
	}
	public float getSpeed() { return velocity.len(); }
	public float getVelocityDirection() { return velocity.angle(); }
	public boolean isAnimationFinished() { 
		return animation.isAnimationFinished(deltaTime);
	}
	public boolean isAnimationPaused() { return bAnimPause; }
	public boolean isMoving() { return (getSpeed() > 0); }
	public void setAcceleration(float acc) { acceleration.setLength(acc); }
	public void setAnimation(Animation<TextureRegion> animation) {
		this.animation = animation;
		TextureRegion tr = animation.getKeyFrame(0);
		float w = tr.getRegionWidth();
		float h = tr.getRegionHeight();
		setSize(w, h);
		setOrigin((w / 2), (h / 2));
	}
	public void setAnimationPaused(boolean pause) {
		if(pause && !bAnimPause) { bAnimPause = pause; onPause(); }
		if(!pause && bAnimPause) { bAnimPause = pause; onResume(); }
	}
	public void setSpeed(float speed) {
		if(velocity.len() == 0) velocity.set(speed, 0);
		else velocity.setLength(speed);
	}
	public void setVelocityDirection(float angle) { velocity.setAngle(angle); }
	
	// Utility functions
	public void pauseAnimation() { setAnimationPaused(true); }
	public void resumeAnimation() { setAnimationPaused(false); }
}
