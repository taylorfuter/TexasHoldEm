package com.CS201L.MyGDKGame;

public class MyGDKGame extends BaseGame {
	public void create() {
		super.create();
		setActiveScreen(new BlackjackScreen());
	}
}