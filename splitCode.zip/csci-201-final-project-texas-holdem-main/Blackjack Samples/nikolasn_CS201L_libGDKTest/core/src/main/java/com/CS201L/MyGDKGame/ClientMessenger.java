package com.CS201L.MyGDKGame;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

public class ClientMessenger extends Thread {
	private Socket s;
	private BufferedReader br;
	private PrintWriter pw;
	
	public ClientMessenger(String host, int port) {
		System.out.println("Starting Client");
		try { s = new Socket(host, port); } 
		catch (UnknownHostException e) { e.printStackTrace(); }
		catch (IOException e) { e.printStackTrace(); }
		System.out.println("Client Started");
		System.out.println("Client port: " + s.getLocalPort());
		
		try {
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream(), true);
		} catch (IOException e) { e.printStackTrace(); }
	}
	
	public void echoServer(String msg) { pw.println(msg); }
	protected void messageHandler(String msg_command) {
		return;
	}
	@Override
	public void run() {
		String msg_server = "";
		while(!msg_server.equals("quit"))
		{
			if(!s.isConnected()) { 
				System.out.println("Connection broken");
				break;
			}
			try { msg_server = br.readLine(); messageHandler(msg_server); } 
			catch (SocketException e) {
				System.out.println("Connection broken");
				break;
			}
			catch (IOException e) { e.printStackTrace(); }
		}
		try { br.close(); pw.close(); System.out.println("Server connection lost."); }
		catch (IOException e) { e.printStackTrace(); }
	}
}
