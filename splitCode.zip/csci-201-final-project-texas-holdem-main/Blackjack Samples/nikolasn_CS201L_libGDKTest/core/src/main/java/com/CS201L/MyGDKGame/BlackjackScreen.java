package com.CS201L.MyGDKGame;

import java.util.Map;
import java.util.TreeMap;

public class BlackjackScreen extends BaseScreen {
	BlackjackClient client;
	BlackjackCardDisplay dealer;
	BlackjackCardDisplay player;
	Map<Integer,BlackjackCardDisplay> opponents;
		
	private GameElement felt;
	private GameElement winMessage;
		
	@Override
	public void initialize() {		
		opponents = new TreeMap<Integer,BlackjackCardDisplay>();
		
		client = new BlackjackClient("localhost", 6789, this);
		client.start();
		
		felt = new GameElement(0, 0, mainStage);
		felt.loadTexture("felt_blackjack.jpg");
		winMessage = new GameElement(0, 0, uiStage);
		winMessage.loadTexture("you-win.png");
		winMessage.setVisible(false);
	}
	@Override
	public void update(float dt) {
		if(dealer != null) dealer.update();
		if(player != null) player.update();
		for(BlackjackCardDisplay display : opponents.values()) display.update();
	}
	
	public void addDealer() {
		dealer = new BlackjackCardDisplay(520, 400, mainStage, 0);
	}
	public void addOpponent(Integer id) {
		BlackjackCardDisplay opponent;
		if(opponents.size() == 1)
			opponent = new BlackjackCardDisplay(900, 20, mainStage, 0);
		else if(opponents.size() == 2) 
			opponent = new BlackjackCardDisplay(20, 400, mainStage, 270);
		else if(opponents.size() == 2)
			opponent = new BlackjackCardDisplay(2000, 400, mainStage, 90);
		else opponent = new BlackjackCardDisplay(20, 20, mainStage, 0);
		opponents.put(id, opponent);
	}
	public void addPlayer() {
		player = new BlackjackCardDisplay(520, 20, mainStage, 0);
	}
	public void dealDealerPriv() {
		if(dealer != null) dealer.addPrivateCard(-1);
	}
	public void dealDealerPub(Integer cardValue) {
		if(dealer != null) dealer.addPublicCard(cardValue);
	}
	public void dealOpponentPriv(Integer id) {
		if(opponents.containsKey(id))
			opponents.get(id).addPrivateCard(-1);
	}
	public void dealOpponentPub(Integer id, Integer cardValue) {
		if(opponents.containsKey(id))
			opponents.get(id).addPublicCard(cardValue);
	}
	public void dealPlayerPriv(Integer cardValue) {
		if(player != null) player.addPrivateCard(cardValue);
	}
	public void dealPlayerPub(Integer cardValue) {
		if(player != null) player.addPublicCard(cardValue);
	}
}
