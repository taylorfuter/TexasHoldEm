package com.CS201L.MyGDKGame;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class Card extends DraggableElement {
	public Integer cardValue;
	private boolean bLoaded;
	
	public Card(float x, float y, Stage s) { 
		super(x, y, s);
		cardValue = -1;
		bLoaded = false;
	}
	public Card(float x, float y, Stage s, Integer card) {
		super(x, y, s);
		cardValue = card;
		bLoaded = false;
	}
	
	public void act(float dt) { super.act(dt); }
	
	public boolean isLoaded() { return bLoaded; }
	public void load() {		
		if(cardValue < 0) { 
			loadTexture("cards/card_back.jpg");
			bLoaded = true;
			return;
		}
		
		StringBuffer strBuf = new StringBuffer("cards/");
		switch(cardValue / 13) {
		case 0: strBuf.append("spades_"); break;
		case 1: strBuf.append("hearts_"); break;
		case 2: strBuf.append("clubs_"); break;
		case 3: strBuf.append("diamonds_"); break;
		default: 
			loadTexture("cards/joker.jpg");
			bLoaded = true;
			return;
		}
		strBuf.append((cardValue % 13) + 1);
		strBuf.append(".jpg");
		
		loadTexture(strBuf.toString());
		bLoaded = true;
	}
}
