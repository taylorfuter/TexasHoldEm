package com.CS201L.MyGDKGame;

import java.util.ArrayList;
import java.util.List;

public class BlackjackPlayer {
	public boolean b_priv_card;
	public List<Integer> pub_cards;
	
	public BlackjackPlayer() { 
		b_priv_card = false; 
		pub_cards = java.util.Collections.synchronizedList(new ArrayList<Integer>());
	}
	
	public void addCard(Integer card) { pub_cards.add(card); }
	public void dealPrivateCard() { b_priv_card = true; }
	public boolean isDealtPrivate() { return b_priv_card; }
}
