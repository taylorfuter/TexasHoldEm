package com.CS201L.MyGDKGame;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class BlackjackCardDisplay {
	protected Stage stage;
	
	public Card priv_card;
	public List<Card> pub_cards;
	
	protected float displayX;
	protected float displayY;
	protected float rotation;
	
	public BlackjackCardDisplay(float x, float y, Stage s) { this(x, y, s, 0.0f); }
	public BlackjackCardDisplay(float x, float y, Stage s, float rotation) {
		stage = s;
		pub_cards = new ArrayList<Card>();
		
		displayX = x;
		displayY = y;
		this.rotation = rotation;
	}
	
	public void addPrivateCard(int cardValue) {
		Vector2 displayCoord = new Vector2(displayX, displayY);
		displayCoord.rotate(rotation);
		priv_card = new Card(displayCoord.x, displayCoord.y, stage, cardValue);
	}
	public void addPublicCard(int cardValue) {
		Vector2 displayCoord = new Vector2(displayX + 256 + (32 * pub_cards.size()),
				displayY);
		displayCoord.rotate(rotation);
		pub_cards.add(new Card(displayCoord.x, displayCoord.y, stage, cardValue));
	}
	public void update() {
		if(priv_card != null && !priv_card.isLoaded()) priv_card.load();
		for(Card c : pub_cards) if(!c.isLoaded()) c.load();
	}
}
