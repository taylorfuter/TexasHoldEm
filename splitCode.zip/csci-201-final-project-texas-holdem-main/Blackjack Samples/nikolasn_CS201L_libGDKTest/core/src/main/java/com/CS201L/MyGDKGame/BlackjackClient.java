package com.CS201L.MyGDKGame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlackjackClient extends ClientMessenger {	
	protected Integer playerID;
	
	public boolean priv_dealerCard;
	public List<Integer> pub_dealerCards;
	public Map<Integer,BlackjackPlayer> playerList;
	
	public Integer priv_card;
	public BlackjackPlayer player;
	
	private boolean bHit;
	
	private BlackjackScreen screen;
	
	public BlackjackClient(String host, int port, BlackjackScreen screen) { 
		super(host, port);
		playerList = java.util.Collections.synchronizedMap(
				new HashMap<Integer,BlackjackPlayer>());
		pub_dealerCards = java.util.Collections.synchronizedList(new ArrayList<Integer>());
		priv_dealerCard = false;
		
		bHit = false;
		
		this.screen = screen;
	}
	
	@Override
	protected void messageHandler(String msg_command) {
		String[] args = msg_command.split("\\s");
		System.out.println("Message from Server: " + msg_command);
		for(int i = 0; i < args.length; i++) System.out.println("\t" + args[i]);
		switch(args[0])
		{
		case "accept":
			try {
				Integer id = Integer.parseInt(args[1]);
				System.out.println("\t - ID: " + id);
				playerID = id;
				addPlayer(id);
				screen.addDealer();
				screen.addPlayer();
			}
			catch(NumberFormatException e) { 
				System.out.println("Error in accept command"); 
			}
			break;
		case "dealer":
			try {
				if(args[1].equals("priv")) {
					priv_dealerCard = true;
					screen.dealDealerPriv();
				}
				else if(args[1].equals("pub"))
				{
					Integer card = Integer.parseInt(args[2]);
					System.out.println("\t - Card: " + card);
					pub_dealerCards.add(card);
					screen.dealDealerPub(card);
				}
				else System.out.println("Unknown server message");
			}
			catch(NumberFormatException e) { 
				System.out.println("Error in dealer command");
			}
			break;
		case "player":
			try {
				Integer id = Integer.parseInt(args[1]);
				System.out.println("\t - ID: " + id);
				addPlayer(id);
				player = playerList.get(id);
				if(id != playerID)
					screen.addOpponent(id);
			}
			catch(NumberFormatException e) { 
				System.out.println("Error in player command");
			}
			break;
		case "priv_card":
			try {
				Integer id = Integer.parseInt(args[1]);
				System.out.println("\t - ID: " + id);
				playerList.get(id).dealPrivateCard();
				if(id == playerID && (args.length == 3))
				{
					Integer card = Integer.parseInt(args[2]);
					System.out.println("\t - Card: " + card);
					priv_card = card;
					screen.dealPlayerPriv(card);
				}
				else if (id != playerID) screen.dealOpponentPriv(id);
			}
			catch(NumberFormatException e) { 
				System.out.println("Error in priv_card command");
			}
			break;
		case "pub_card":
			try {
				Integer id = Integer.parseInt(args[1]);
				Integer card = Integer.parseInt(args[2]);
				playerList.get(id).addCard(card);
				if(id == playerID) screen.dealPlayerPub(card);
				else screen.dealOpponentPub(id, card);
			}
			catch(NumberFormatException e) { 
				System.out.println("Error in pub_card command"); }
			break;
		case "query":
			try {
				if(args[1].equals("hit"))
					echoServer("" + bHit);
				else System.out.println("Error in query command");
			}
			catch(NumberFormatException e) {
				System.out.println("Error in query command");
			}
		default:
			System.out.println("Unknown server message");
		}
	}
	public void addPlayer(Integer id) { playerList.put(id, new BlackjackPlayer()); }
	
	// Get-Set Functions
	public boolean isHit() { return bHit; };
	public void setHit(boolean hit) { bHit = hit; }
	public Integer getSum() { 
		Integer sum = 0;
		
		int aceCount = 0;
		for(Integer card : player.pub_cards) {
			Integer pub_val = (card % 13) + 1;
			if(pub_val > 10) pub_val = 10;
			if(pub_val == 1) aceCount++;
			sum += pub_val;
		}
		
		Integer priv_val = (priv_card % 13) + 1;
		if(priv_val > 10) priv_val = 10;
		if(priv_val == 1) aceCount++;
		sum += priv_val;
		
		for(int i = 0; i < aceCount; i++)
			if(sum < 11) sum += 10;
		
		return sum;
	}
}
